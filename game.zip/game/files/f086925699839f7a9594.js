function _typeof(obj) { if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

(function (f) {
  if ((typeof exports === "undefined" ? "undefined" : _typeof(exports)) === "object" && typeof module !== "undefined") {
    module.exports = f();
  } else if (typeof define === "function" && define.amd) {
    define([], f);
  } else {
    var g;

    if (typeof window !== "undefined") {
      g = window;
    } else if (typeof global !== "undefined") {
      g = global;
    } else if (typeof self !== "undefined") {
      g = self;
    } else {
      g = this;
    }

    g.aez_bundle_main = f();
  }
})(function () {
  var define, module, exports;
  return function () {
    function r(e, n, t) {
      function o(i, f) {
        if (!n[i]) {
          if (!e[i]) {
            var c = "function" == typeof require && require;
            if (!f && c) return c(i, !0);
            if (u) return u(i, !0);
            var a = new Error("Cannot find module '" + i + "'");
            throw a.code = "MODULE_NOT_FOUND", a;
          }

          var p = n[i] = {
            exports: {}
          };
          e[i][0].call(p.exports, function (r) {
            var n = e[i][1][r];
            return o(n || r);
          }, p, p.exports, r, e, n, t);
        }

        return n[i].exports;
      }

      for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) {
        o(t[i]);
      }

      return o;
    }

    return r;
  }()({
    1: [function (require, module, exports) {
      "use strict";

      var ActionType;

      (function (ActionType) {
        ActionType[ActionType["Wait"] = 0] = "Wait";
        ActionType[ActionType["Call"] = 1] = "Call";
        ActionType[ActionType["TweenTo"] = 2] = "TweenTo";
        ActionType[ActionType["TweenBy"] = 3] = "TweenBy";
        ActionType[ActionType["TweenByMult"] = 4] = "TweenByMult";
        ActionType[ActionType["Cue"] = 5] = "Cue";
        ActionType[ActionType["Every"] = 6] = "Every";
      })(ActionType || (ActionType = {}));

      module.exports = ActionType;
    }, {}],
    2: [function (require, module, exports) {
      "use strict";
      /**
       * Easing関数群。
       * 参考: http://gizma.com/easing/
       */

      var Easing;

      (function (Easing) {
        /**
         * 入力値をlinearした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function linear(t, b, c, d) {
          return c * t / d + b;
        }

        Easing.linear = linear;
        /**
         * 入力値をeaseInQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuad(t, b, c, d) {
          t /= d;
          return c * t * t + b;
        }

        Easing.easeInQuad = easeInQuad;
        /**
         * 入力値をeaseOutQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuad(t, b, c, d) {
          t /= d;
          return -c * t * (t - 2) + b;
        }

        Easing.easeOutQuad = easeOutQuad;
        /**
         * 入力値をeaseInOutQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutQuad(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t + b;
          --t;
          return -c / 2 * (t * (t - 2) - 1) + b;
        }

        Easing.easeInOutQuad = easeInOutQuad;
        /**
         * 入力値をeaseInQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInCubic(t, b, c, d) {
          t /= d;
          return c * t * t * t + b;
        }

        Easing.easeInCubic = easeInCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeInCubic` を用いるべきである。
         */

        Easing.easeInQubic = easeInCubic;
        /**
         * 入力値をeaseOutQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutCubic(t, b, c, d) {
          t /= d;
          --t;
          return c * (t * t * t + 1) + b;
        }

        Easing.easeOutCubic = easeOutCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeOutCubic` を用いるべきである。
         */

        Easing.easeOutQubic = easeOutCubic;
        /**
         * 入力値をeaseInOutQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutCubic(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t * t + b;
          t -= 2;
          return c / 2 * (t * t * t + 2) + b;
        }

        Easing.easeInOutCubic = easeInOutCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeInOutCubic` を用いるべきである。
         */

        Easing.easeInOutQubic = easeInOutCubic;
        /**
         * 入力値をeaseInQuartした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuart(t, b, c, d) {
          t /= d;
          return c * t * t * t * t + b;
        }

        Easing.easeInQuart = easeInQuart;
        /**
         * 入力値をeaseOutQuartした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuart(t, b, c, d) {
          t /= d;
          --t;
          return -c * (t * t * t * t - 1) + b;
        }

        Easing.easeOutQuart = easeOutQuart;
        /**
         * 入力値をeaseInQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuint(t, b, c, d) {
          t /= d;
          return c * t * t * t * t * t + b;
        }

        Easing.easeInQuint = easeInQuint;
        /**
         * 入力値をeaseOutQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuint(t, b, c, d) {
          t /= d;
          --t;
          return c * (t * t * t * t * t + 1) + b;
        }

        Easing.easeOutQuint = easeOutQuint;
        /**
         * 入力値をeaseInOutQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutQuint(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t * t * t * t + b;
          t -= 2;
          return c / 2 * (t * t * t * t * t + 2) + b;
        }

        Easing.easeInOutQuint = easeInOutQuint;
        /**
         * 入力値をeaseInSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInSine(t, b, c, d) {
          return -c * Math.cos(t / d * (Math.PI / 2)) + c + b;
        }

        Easing.easeInSine = easeInSine;
        /**
         * 入力値をeaseOutSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutSine(t, b, c, d) {
          return c * Math.sin(t / d * (Math.PI / 2)) + b;
        }

        Easing.easeOutSine = easeOutSine;
        /**
         * 入力値をeaseInOutSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutSine(t, b, c, d) {
          return -c / 2 * (Math.cos(Math.PI * t / d) - 1) + b;
        }

        Easing.easeInOutSine = easeInOutSine;
        /**
         * 入力値をeaseInExpoした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInExpo(t, b, c, d) {
          return c * Math.pow(2, 10 * (t / d - 1)) + b;
        }

        Easing.easeInExpo = easeInExpo;
        /**
         * 入力値をeaseInOutExpoした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutExpo(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * Math.pow(2, 10 * (t - 1)) + b;
          --t;
          return c / 2 * (-Math.pow(2, -10 * t) + 2) + b;
        }

        Easing.easeInOutExpo = easeInOutExpo;
        /**
         * 入力値をeaseInCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInCirc(t, b, c, d) {
          t /= d;
          return -c * (Math.sqrt(1 - t * t) - 1) + b;
        }

        Easing.easeInCirc = easeInCirc;
        /**
         * 入力値をeaseOutCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutCirc(t, b, c, d) {
          t /= d;
          --t;
          return c * Math.sqrt(1 - t * t) + b;
        }

        Easing.easeOutCirc = easeOutCirc;
        /**
         * 入力値をeaseInOutCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutCirc(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return -c / 2 * (Math.sqrt(1 - t * t) - 1) + b;
          t -= 2;
          return c / 2 * (Math.sqrt(1 - t * t) + 1) + b;
        }

        Easing.easeInOutCirc = easeInOutCirc;
      })(Easing || (Easing = {}));

      module.exports = Easing;
    }, {}],
    3: [function (require, module, exports) {
      "use strict";

      var Tween = require("./Tween");
      /**
       * タイムライン機能を提供するクラス。
       */


      var Timeline =
      /** @class */
      function () {
        /**
         * Timelineを生成する。
         * @param scene タイムラインを実行する `Scene`
         */
        function Timeline(scene) {
          this._scene = scene;
          this._tweens = [];
          this._fps = this._scene.game.fps;
          this.paused = false;
          scene.update.add(this._handler, this);
        }
        /**
         * Timelineに紐付いたTweenを生成する。
         * @param target タイムライン処理の対象にするオブジェクト
         * @param option Tweenの生成オプション
         */


        Timeline.prototype.create = function (target, option) {
          var t = new Tween(target, option);

          this._tweens.push(t);

          return t;
        };
        /**
         * Timelineに紐付いたTweenを削除する。
         * @param tween 削除するTween。
         */


        Timeline.prototype.remove = function (tween) {
          var index = this._tweens.indexOf(tween);

          if (index < 0) {
            return;
          }

          this._tweens.splice(index, 1);
        };
        /**
         * Timelineに紐付いた全Tweenの紐付けを解除する。
         */


        Timeline.prototype.clear = function () {
          this._tweens.length = 0;
        };
        /**
         * このTimelineを破棄する。
         */


        Timeline.prototype.destroy = function () {
          this._tweens.length = 0;

          if (!this._scene.destroyed()) {
            this._scene.update.remove(this._handler, this);
          }

          this._scene = undefined;
        };
        /**
         * このTimelineが破棄済みであるかを返す。
         */


        Timeline.prototype.destroyed = function () {
          return this._scene === undefined;
        };

        Timeline.prototype._handler = function () {
          if (this._tweens.length === 0 || this.paused) {
            return;
          }

          var tmp = [];

          for (var i = 0; i < this._tweens.length; ++i) {
            var tween = this._tweens[i];

            if (!tween.destroyed()) {
              tween._fire(1000 / this._fps);

              tmp.push(tween);
            }
          }

          this._tweens = tmp;
        };

        return Timeline;
      }();

      module.exports = Timeline;
    }, {
      "./Tween": 4
    }],
    4: [function (require, module, exports) {
      "use strict";

      var Easing = require("./Easing");

      var ActionType = require("./ActionType");
      /**
       * オブジェクトの状態を変化させるアクションを定義するクラス。
       * 本クラスのインスタンス生成には`Timeline#create()`を利用する。
       */


      var Tween =
      /** @class */
      function () {
        /**
         * Tweenを生成する。
         * @param target 対象となるオブジェクト
         * @param option オプション
         */
        function Tween(target, option) {
          this._target = target;
          this._stepIndex = 0;
          this._loop = !!option && !!option.loop;
          this._modifiedHandler = option && option.modified ? option.modified : undefined;
          this._destroyedHandler = option && option.destroyed ? option.destroyed : undefined;
          this._steps = [];
          this._lastStep = undefined;
          this._pararel = false;
          this.paused = false;
        }
        /**
         * オブジェクトの状態を変化させるアクションを追加する。
         * @param props 変化内容
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.to = function (props, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: ActionType.TweenTo,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * オブジェクトの状態を変化させるアクションを追加する。
         * 変化内容はアクション開始時を基準とした相対値で指定する。
         * @param props 変化内容
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         * @param multiply `true`を指定すると`props`の値をアクション開始時の値に掛け合わせた値が終了値となる（指定しない場合は`false`）
         */


        Tween.prototype.by = function (props, duration, easing, multiply) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          if (multiply === void 0) {
            multiply = false;
          }

          var type = multiply ? ActionType.TweenByMult : ActionType.TweenBy;
          var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: type,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 次に追加されるアクションを、このメソッド呼び出しの直前に追加されたアクションと並列に実行させる。
         * `Tween#con()`で並列実行を指定されたアクションが全て終了後、次の並列実行を指定されていないアクションを実行する。
         */


        Tween.prototype.con = function () {
          this._pararel = true;
          return this;
        };
        /**
         * オブジェクトの変化を停止するアクションを追加する。
         * @param duration 停止する時間（ミリ秒）
         */


        Tween.prototype.wait = function (duration) {
          var action = {
            duration: duration,
            type: ActionType.Wait,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 関数を即座に実行するアクションを追加する。
         * @param func 実行する関数
         */


        Tween.prototype.call = function (func) {
          var action = {
            func: func,
            type: ActionType.Call,
            duration: 0,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 一時停止するアクションを追加する。
         * 内部的には`Tween#call()`で`Tween#paused`に`true`をセットしている。
         */


        Tween.prototype.pause = function () {
          var _this = this;

          return this.call(function () {
            _this.paused = true;
          });
        };
        /**
         * 待機時間をキーとして実行したい関数を複数指定する。
         * @param actions 待機時間をキーとして実行したい関数を値としたオブジェクト
         */


        Tween.prototype.cue = function (funcs) {
          var keys = Object.keys(funcs);
          keys.sort(function (a, b) {
            return Number(a) > Number(b) ? 1 : -1;
          });
          var q = [];

          for (var i = 0; i < keys.length; ++i) {
            q.push({
              time: Number(keys[i]),
              func: funcs[keys[i]]
            });
          }

          var action = {
            type: ActionType.Cue,
            duration: Number(keys[keys.length - 1]),
            cue: q,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 指定した時間を経過するまで毎フレーム指定した関数を呼び出すアクションを追加する。
         * @param func 毎フレーム呼び出される関数。第一引数は経過時間、第二引数はEasingした結果の変化量（0-1）となる。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.every = function (func, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          var action = {
            func: func,
            type: ActionType.Every,
            easing: easing,
            duration: duration,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * ターゲットをフェードインさせるアクションを追加する。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.fadeIn = function (duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            opacity: 1
          }, duration, easing);
        };
        /**
         * ターゲットをフェードアウトさせるアクションを追加する。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.fadeOut = function (duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            opacity: 0
          }, duration, easing);
        };
        /**
         * ターゲットを指定した座標に移動するアクションを追加する。
         * @param x x座標
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveTo = function (x, y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            x: x,
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットを指定した相対座標に移動するアクションを追加する。相対座標の基準値はアクション開始時の座標となる。
         * @param x x座標
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveBy = function (x, y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            x: x,
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットのX座標を指定した座標に移動するアクションを追加する。
         * @param x x座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveX = function (x, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            x: x
          }, duration, easing);
        };
        /**
         * ターゲットのY座標を指定した座標に移動するアクションを追加する。
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveY = function (y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットを指定した角度に回転するアクションを追加する。
         * @param angle 角度
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.rotateTo = function (angle, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            angle: angle
          }, duration, easing);
        };
        /**
         * ターゲットをアクション開始時の角度を基準とした相対角度に回転するアクションを追加する。
         * @param angle 角度
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.rotateBy = function (angle, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            angle: angle
          }, duration, easing);
        };
        /**
         * ターゲットを指定した倍率に拡縮するアクションを追加する。
         * @param scaleX X方向の倍率
         * @param scaleY Y方向の倍率
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.scaleTo = function (scaleX, scaleY, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            scaleX: scaleX,
            scaleY: scaleY
          }, duration, easing);
        };
        /**
         * ターゲットのアクション開始時の倍率に指定した倍率を掛け合わせた倍率に拡縮するアクションを追加する。
         * @param scaleX X方向の倍率
         * @param scaleY Y方向の倍率
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.scaleBy = function (scaleX, scaleY, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            scaleX: scaleX,
            scaleY: scaleY
          }, duration, easing, true);
        };
        /**
         * Tweenが破棄されたかどうかを返す。
         * `_target`が破棄された場合又は、全アクションの実行が終了した場合に`true`を返す。
         */


        Tween.prototype.destroyed = function () {
          var ret = false;

          if (this._destroyedHandler) {
            ret = this._destroyedHandler.call(this._target);
          }

          if (!ret) {
            ret = this._stepIndex >= this._steps.length && !this._loop;
          }

          return ret;
        };
        /**
         * アニメーションを実行する。
         * @param delta 前フレームからの経過時間
         */


        Tween.prototype._fire = function (delta) {
          if (this._steps.length === 0 || this.destroyed() || this.paused) {
            return;
          }

          if (this._stepIndex >= this._steps.length) {
            if (this._loop) {
              this._stepIndex = 0;
            } else {
              return;
            }
          }

          var actions = this._steps[this._stepIndex];
          var remained = false;

          for (var i = 0; i < actions.length; ++i) {
            var action = actions[i];

            if (!action.initialized) {
              this._initAction(action);
            }

            if (action.finished) {
              continue;
            }

            action.elapsed += delta;

            switch (action.type) {
              case ActionType.Call:
                action.func.call(this._target);
                break;

              case ActionType.Every:
                var progress = action.easing(action.elapsed, 0, 1, action.duration);

                if (progress > 1) {
                  progress = 1;
                }

                action.func.call(this._target, action.elapsed, progress);
                break;

              case ActionType.TweenTo:
              case ActionType.TweenBy:
              case ActionType.TweenByMult:
                var keys = Object.keys(action.goal);

                for (var j = 0; j < keys.length; ++j) {
                  var key = keys[j];

                  if (action.elapsed >= action.duration) {
                    this._target[key] = action.goal[key];
                  } else {
                    this._target[key] = action.easing(action.elapsed, action.start[key], action.goal[key] - action.start[key], action.duration);
                  }
                }

                break;

              case ActionType.Cue:
                var cueAction = action.cue[action.cueIndex];

                if (cueAction !== undefined && action.elapsed >= cueAction.time) {
                  cueAction.func.call(this._target);
                  ++action.cueIndex;
                }

                break;
            }

            if (this._modifiedHandler) {
              this._modifiedHandler.call(this._target);
            }

            if (action.elapsed >= action.duration) {
              action.finished = true;
            } else {
              remained = true;
            }
          }

          if (!remained) {
            for (var k = 0; k < actions.length; ++k) {
              actions[k].initialized = false;
            }

            ++this._stepIndex;
          }
        };
        /**
         * Tweenの実行状態をシリアライズして返す。
         */


        Tween.prototype.serializeState = function () {
          var tData = {
            _stepIndex: this._stepIndex,
            _steps: []
          };

          for (var i = 0; i < this._steps.length; ++i) {
            tData._steps[i] = [];

            for (var j = 0; j < this._steps[i].length; ++j) {
              tData._steps[i][j] = {
                input: this._steps[i][j].input,
                start: this._steps[i][j].start,
                goal: this._steps[i][j].goal,
                duration: this._steps[i][j].duration,
                elapsed: this._steps[i][j].elapsed,
                type: this._steps[i][j].type,
                cueIndex: this._steps[i][j].cueIndex,
                initialized: this._steps[i][j].initialized,
                finished: this._steps[i][j].finished
              };
            }
          }

          return tData;
        };
        /**
         * Tweenの実行状態を復元する。
         * @param serializedstate 復元に使う情報。
         */


        Tween.prototype.deserializeState = function (serializedState) {
          this._stepIndex = serializedState._stepIndex;

          for (var i = 0; i < serializedState._steps.length; ++i) {
            for (var j = 0; j < serializedState._steps[i].length; ++j) {
              if (!serializedState._steps[i][j] || !this._steps[i][j]) continue;
              this._steps[i][j].input = serializedState._steps[i][j].input;
              this._steps[i][j].start = serializedState._steps[i][j].start;
              this._steps[i][j].goal = serializedState._steps[i][j].goal;
              this._steps[i][j].duration = serializedState._steps[i][j].duration;
              this._steps[i][j].elapsed = serializedState._steps[i][j].elapsed;
              this._steps[i][j].type = serializedState._steps[i][j].type;
              this._steps[i][j].cueIndex = serializedState._steps[i][j].cueIndex;
              this._steps[i][j].initialized = serializedState._steps[i][j].initialized;
              this._steps[i][j].finished = serializedState._steps[i][j].finished;
            }
          }
        };
        /**
         * `this._pararel`が`false`の場合は新規にステップを作成し、アクションを追加する。
         * `this._pararel`が`true`の場合は最後に作成したステップにアクションを追加する。
         */


        Tween.prototype._push = function (action) {
          if (this._pararel) {
            this._lastStep.push(action);
          } else {
            var index = this._steps.push([action]) - 1;
            this._lastStep = this._steps[index];
          }

          this._pararel = false;
        };

        Tween.prototype._initAction = function (action) {
          action.elapsed = 0;
          action.start = {};
          action.goal = {};
          action.cueIndex = 0;
          action.finished = false;
          action.initialized = true;

          if (action.type !== ActionType.TweenTo && action.type !== ActionType.TweenBy && action.type !== ActionType.TweenByMult) {
            return;
          }

          var keys = Object.keys(action.input);

          for (var i = 0; i < keys.length; ++i) {
            var key = keys[i];

            if (this._target[key] !== undefined) {
              action.start[key] = this._target[key];

              if (action.type === ActionType.TweenTo) {
                action.goal[key] = action.input[key];
              } else if (action.type === ActionType.TweenBy) {
                action.goal[key] = action.start[key] + action.input[key];
              } else if (action.type === ActionType.TweenByMult) {
                action.goal[key] = action.start[key] * action.input[key];
              }
            }
          }
        };

        return Tween;
      }();

      module.exports = Tween;
    }, {
      "./ActionType": 1,
      "./Easing": 2
    }],
    5: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Timeline = require("./Timeline");
      exports.Tween = require("./Tween");
      exports.Easing = require("./Easing");
    }, {
      "./Easing": 2,
      "./Timeline": 3,
      "./Tween": 4
    }],
    6: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var akashic_timeline_1 = require("@akashic-extension/akashic-timeline");

      var GameBackground =
      /** @class */
      function (_super) {
        __extends(GameBackground, _super);

        function GameBackground(params) {
          var _this = _super.call(this, {
            scene: params.scene,
            width: params.scene.game.width,
            height: params.scene.game.height
          }) || this;

          _this.timeline = new akashic_timeline_1.Timeline(params.scene);
          _this.background0 = new g.FilledRect({
            scene: _this.scene,
            cssColor: '#98d98e',
            // cssColor: '#bafbb0',
            width: params.scene.game.width,
            height: params.scene.game.height
          });
          _this.background1 = new g.E({
            scene: _this.scene,
            width: params.scene.game.width,
            height: params.scene.game.height
          });
          _this.background2 = new g.E({
            scene: _this.scene,
            width: params.scene.game.width,
            height: params.scene.game.height
          });
          _this.background1.x = -params.scene.game.width;
          _this.background2.x = 0;
          var asiatoPositions = [{
            x: 50,
            y: 50,
            angle: -10,
            scale: 0.35
          }, {
            x: 110,
            y: 300,
            angle: -30,
            scale: 0.2
          }, {
            x: 130,
            y: 90,
            angle: -50,
            scale: 0.3
          }, {
            x: 300,
            y: 150,
            angle: -90,
            scale: 0.35
          }, {
            x: 430,
            y: 20,
            angle: -70,
            scale: 0.18
          }, {
            x: 500,
            y: 270,
            angle: -40,
            scale: 0.25
          }];
          asiatoPositions.forEach(function (v) {
            _this.background1.append(new g.Sprite({
              scene: _this.scene,
              src: params.scene.assets['asiato'],
              x: v.x,
              y: v.y,
              angle: v.angle,
              scaleX: v.scale,
              scaleY: v.scale
            }));

            _this.background2.append(new g.Sprite({
              scene: _this.scene,
              src: params.scene.assets['asiato'],
              x: v.x,
              y: v.y,
              angle: v.angle,
              scaleX: v.scale,
              scaleY: v.scale
            }));
          });

          _this.append(_this.background0);

          _this.append(_this.background1);

          _this.append(_this.background2);

          return _this;
        }

        GameBackground.prototype.step = function (x) {
          if (this.background2.x + x > this.scene.game.width) {
            this.background1.x -= this.scene.game.width;
            this.background2.x -= this.scene.game.width;
          }

          this.background1.modified();
          this.background2.modified();
          this.timeline.create(this.background1, {
            modified: this.background1.modified,
            destroyed: this.background1.destroyed
          }).moveBy(x, 0, 50);
          this.timeline.create(this.background2, {
            modified: this.background2.modified,
            destroyed: this.background2.destroyed
          }).moveBy(x, 0, 50);
        };

        return GameBackground;
      }(g.E);

      exports.GameBackground = GameBackground;
    }, {
      "@akashic-extension/akashic-timeline": 5
    }],
    7: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var Util_1 = require("../util/Util");

      var GameManager =
      /** @class */
      function (_super) {
        __extends(GameManager, _super);

        function GameManager(params) {
          var _this = _super.call(this, {
            scene: params.scene,
            width: params.scene.game.width,
            height: params.scene.game.height,
            local: true
          }) || this;
          /**
           * ※ BB: 1拍の長さ
           *              |    0.2 BB    |        0.3 BB      |
           *              |       |0.1 BB|   0.2 BB  |        |
           *   miss       | good  |    great         |  good  |  miss
           *              |       |      |           |        |
           * ----------------------------B-----------------------------
           *                           (↑Beat)
           */


          _this.GREAT_MARGIN_FW = 0.2;
          _this.GREAT_MARGIN_BW = 0.1;
          _this.GOOD_MARGIN_FW = 0.3;
          _this.GOOD_MARGIN_BW = 0.2;
          _this.score = params.score;
          _this.loop = !!params.loop;
          _this.onBeat = new g.Trigger();
          _this.onBeatActionStatusFixed = new g.Trigger();
          _this.onCount = new g.Trigger();
          _this.onLastSomeMeasures = new g.Trigger();

          _this.update.add(_this.onUpdate.bind(_this));

          return _this;
        }

        GameManager.prototype.start = function () {
          this.initializeTimeline(this.score, this.scene.game.age + 60);
          this.currentTimelineIndex = -1; // console.log('timeline', this.timeline);
        };

        GameManager.prototype.stop = function () {
          this.timeline = null;
        };

        GameManager.prototype.onUpdate = function () {
          var _this = this;

          if (!this.timeline) {
            return;
          } // 今のタイムラインの beatActionStatus をチェック Waiting かつ Fail となる範囲なら Fail とする


          if (this.timeline[this.currentTimelineIndex] && this.timeline[this.currentTimelineIndex].beatActionStatus === 0
          /* Waiting */
          && (this.timeline[this.currentTimelineIndex].beatAction === 2
          /* Normal */
          || this.timeline[this.currentTimelineIndex].beatAction === 3
          /* PiPyako */
          )) {
            if (this.scene.game.age - this.timeline[this.currentTimelineIndex].age > this.agePerBeat * this.GOOD_MARGIN_FW) {
              console.log('超過 failed', this.currentTimelineIndex);
              this.timeline[this.currentTimelineIndex].beatActionStatus = 3
              /* Fail */
              ;
              this.onBeatActionStatusFixed.fire({
                status: this.timeline[this.currentTimelineIndex].beatActionStatus
              });
            }
          } // 次のタイムラインの時刻を過ぎていたら、


          if (this.timeline[this.currentTimelineIndex + 1] && this.timeline[this.currentTimelineIndex + 1].age < this.scene.game.age) {
            // タイムラインを進める
            this.currentTimelineIndex++;
            this.beatExec(this.currentTimelineIndex);
          } // loop設定がオンで、次のタイムラインがないかつ1拍分時間が経っていたら


          if (this.loop && !this.timeline[this.currentTimelineIndex + 1] && this.timeline[this.currentTimelineIndex].age + this.agePerBeat < this.scene.game.age) {
            // リセット
            this.currentTimelineIndex = 0;
            this.timeline.forEach(function (v, index) {
              v.beatActionStatus = 0
              /* Waiting */
              ;
              v.age = _this.scene.game.age + _this.agePerBeat * index;
            }); // このタイミングがループ後の1拍目なのでここでも beat時の処理を実行

            this.beatExec(this.currentTimelineIndex);
            console.log('reset', this.timeline);
          }
        };
        /**
         * 確定した結果の beatIndex(小節中の何拍目か) を返します
         */


        GameManager.prototype.action = function (action) {
          // console.log('action', action);
          var nearestIndex = this.timeline[this.currentTimelineIndex].beatActionStatus === 0
          /* Waiting */
          && this.timeline[this.currentTimelineIndex].beatAction !== 0
          /* Count */
          && this.timeline[this.currentTimelineIndex].beatAction !== 1
          /* LastCount */
          ? this.currentTimelineIndex : this.currentTimelineIndex + 1; // console.log('nearestIndex', nearestIndex);

          if (!this.timeline[nearestIndex]) {
            return null;
          }

          if (this.timeline[nearestIndex].beatActionStatus !== 0
          /* Waiting */
          ) {
              // 結果が確定済みならスルー
              return null;
            }

          if (this.timeline[nearestIndex].beatAction !== 2
          /* Normal */
          && this.timeline[nearestIndex].beatAction !== 3
          /* PiPyako */
          ) {
              // console.log('not normal, pipyako');
              return null;
            }

          var isSlideDownExpected = this.timeline[nearestIndex - 2] && this.timeline[nearestIndex - 2].beatAction === 3
          /* PiPyako */
          ;
          var isSlideUpExpected = this.timeline[nearestIndex - 3] && this.timeline[nearestIndex - 3].beatAction === 3
          /* PiPyako */
          ;

          if ( // SlideDown であるべきだが間違い
          isSlideDownExpected && action !== 1
          /* SlideDown */
          || // SlideUp であるべきだが間違い
          isSlideUpExpected && action !== 2
          /* SlideUp */
          || // それ以外(Click)であるべきだが間違い
          !isSlideDownExpected && !isSlideUpExpected && action !== 0
          /* Click */
          ) {
              console.log('miss');
              this.timeline[nearestIndex].beatActionStatus = 3
              /* Fail */
              ;
            } else {
            var timingGap = this.scene.game.age - this.timeline[nearestIndex].age;
            console.log('gap', timingGap);
            var status_1 = (timingGap < 0 ? -this.agePerBeat * this.GREAT_MARGIN_BW < timingGap : timingGap < this.agePerBeat * this.GREAT_MARGIN_FW) ? 1
            /* Great */
            : (timingGap < 0 ? -this.agePerBeat * this.GOOD_MARGIN_BW < timingGap : timingGap < this.agePerBeat * this.GOOD_MARGIN_FW) ? 2
            /* Good */
            : 3
            /* Fail */
            ;
            this.timeline[nearestIndex].beatActionStatus = status_1;
          }

          this.onBeatActionStatusFixed.fire({
            status: this.timeline[nearestIndex].beatActionStatus
          });
          console.log('onBeatActionStatusFixed', nearestIndex, action, this.timeline[nearestIndex].beatActionStatus);
          return nearestIndex % 4;
        };

        GameManager.prototype.getStates = function () {
          return this.timeline.map(function (v) {
            return v.beatActionStatus;
          });
        };

        GameManager.prototype.beatExec = function (timelineIndex) {
          // システムアクションがあれば実行
          if (this.timeline[timelineIndex].systemAction) {
            this.timeline[timelineIndex].systemAction();
          }

          this.onBeat.fire({
            action: this.timeline[timelineIndex].beatAction,
            beatIndex: timelineIndex % this.beat
          });
          console.log('beat!', timelineIndex, this.timeline[timelineIndex]);
        };

        GameManager.prototype.initializeTimeline = function (score, startAge) {
          var _this = this;

          var timeline = [];
          this.agePerBeat = 60 / score.bpm * this.scene.game.fps;
          this.beat = score.beat;
          score.fragments.forEach(function (fragment, fi) {
            fragment.beatAction.forEach(function (beatAction, bi) {
              timeline.push({
                age: startAge + _this.agePerBeat * (fi * score.beat + bi),
                beatAction: beatAction,
                beatActionStatus: 0
                /* Waiting */
                ,
                systemAction: function systemAction() {
                  if (bi === 0) {
                    console.log('playAudio', fragment.assetId);
                    Util_1.Util.playAudio(_this.scene, fragment.assetId);
                  }

                  if (beatAction === 0
                  /* Count */
                  ) {
                      Util_1.Util.playAudio(_this.scene, 'pi');

                      _this.onCount.fire({
                        isLast: false
                      });
                    }

                  if (beatAction === 1
                  /* LastCount */
                  ) {
                      Util_1.Util.playAudio(_this.scene, 'pi');

                      _this.onCount.fire({
                        isLast: true
                      });
                    }

                  if (beatAction === 3
                  /* PiPyako */
                  ) {
                      Util_1.Util.playAudio(_this.scene, 'numa_head');
                    }

                  if (fi === score.fragments.length - 3 && bi === 0) {
                    // 最後から3小節目
                    _this.onLastSomeMeasures.fire({
                      age: 3 * score.beat * _this.agePerBeat
                    });
                  }
                }
              });
            });
          });
          this.timeline = timeline;
        };

        return GameManager;
      }(g.E);

      exports.GameManager = GameManager;
    }, {
      "../util/Util": 29
    }],
    8: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      var Gesture;

      (function (Gesture) {
        Gesture[Gesture["Tap"] = 0] = "Tap";
        Gesture[Gesture["SlideDown"] = 1] = "SlideDown";
        Gesture[Gesture["SlideUp"] = 2] = "SlideUp";
      })(Gesture = exports.Gesture || (exports.Gesture = {}));

      var GestureHandler =
      /** @class */
      function (_super) {
        __extends(GestureHandler, _super);

        function GestureHandler(params) {
          var _this = _super.call(this, {
            scene: params.scene,
            width: params.scene.game.width,
            height: params.scene.game.height,
            touchable: true,
            local: true
          }) || this;

          _this.onTap = new g.Trigger();
          _this.onTapUp = new g.Trigger();
          _this.onSlideDown = new g.Trigger();
          _this.onSlideUp = new g.Trigger();

          _this.pointDown.add(_this.onPointDown.bind(_this));

          _this.pointUp.add(_this.onPointUp.bind(_this));

          _this.pointMove.add(_this.onPointMove.bind(_this));

          return _this;
        }

        GestureHandler.prototype.onPointDown = function (event) {
          var _this = this;

          this.currentTempGesture = Gesture.Tap;
          this.scene.setTimeout(function () {
            if (_this.currentTempGesture === Gesture.Tap && _this.lastGesture !== Gesture.SlideDown && _this.lastGesture !== Gesture.SlideUp) {
              _this.currentTempGesture = null;
              _this.lastGesture = Gesture.Tap;

              _this.onTap.fire(); // console.log('tap');

            }
          }, 100);
        };

        GestureHandler.prototype.onPointUp = function (event) {
          if (this.currentTempGesture === Gesture.Tap) {
            this.lastGesture = Gesture.Tap;
            this.onTap.fire(); // console.log('tap in pointup');
          }

          if (this.lastGesture === Gesture.SlideDown || this.lastGesture === Gesture.SlideUp) {
            this.lastGesture = null;
            return;
          }

          this.currentTempGesture = null;
          this.lastGesture = null;
          this.onTapUp.fire(); // console.log('tapup');
        };

        GestureHandler.prototype.onPointMove = function (event) {
          // console.log('pointmove', event.startDelta);
          if (this.currentTempGesture === Gesture.Tap && this.lastGesture !== Gesture.SlideDown && this.lastGesture !== Gesture.SlideUp && event.startDelta.y > 8) {
            this.currentTempGesture = null;
            this.lastGesture = Gesture.SlideDown;
            this.onSlideDown.fire(); // console.log('slidedown');
          } else if (this.lastGesture === Gesture.SlideDown && event.prevDelta.y < -5) {
            this.currentTempGesture = null;
            this.lastGesture = Gesture.SlideUp;
            this.onSlideUp.fire(); // console.log('slideup');
          }
        };

        return GestureHandler;
      }(g.E);

      exports.GestureHandler = GestureHandler;
    }, {}],
    9: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var RoundedFilledRect_1 = require("./RoundedFilledRect");

      var Label_1 = require("./Label");

      var JoinButton =
      /** @class */
      function (_super) {
        __extends(JoinButton, _super);

        function JoinButton(params) {
          var _this = _super.call(this, {
            scene: params.scene,
            width: 180,
            height: 50,
            touchable: true,
            local: true
          }) || this;

          _this.redBackground = new RoundedFilledRect_1.RoundedFilledRect({
            scene: _this.scene,
            width: _this.width,
            height: _this.height,
            x: 0,
            y: 0,
            borderRadius: 20,
            cssColor: '#c33',
            circleAssetId: 'red_circle_32',
            circleAssetSize: 32
          });

          _this.append(_this.redBackground);

          _this.grayBackground = new RoundedFilledRect_1.RoundedFilledRect({
            scene: _this.scene,
            width: _this.width,
            height: _this.height,
            x: 0,
            y: 0,
            borderRadius: 20,
            cssColor: '#999',
            circleAssetId: 'gray_circle_32',
            circleAssetSize: 32
          });

          _this.grayBackground.hide();

          _this.append(_this.grayBackground);

          _this.text = new Label_1.MediumWhite64pxLabel({
            scene: _this.scene,
            text: '参加する',
            fontSize: 28
          });
          _this.text.x = (_this.width - _this.text.width) / 2;
          _this.text.y = (_this.height - _this.text.height) / 2;

          _this.append(_this.text);

          return _this;
        }

        JoinButton.prototype.setJoined = function () {
          this.redBackground.hide();
          this.grayBackground.show();
          this.text.text = '参加済み';
          this.text.invalidate();
        };

        return JoinButton;
      }(g.E);

      exports.JoinButton = JoinButton;
    }, {
      "./Label": 10,
      "./RoundedFilledRect": 14
    }],
    10: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var Label =
      /** @class */
      function (_super) {
        __extends(Label, _super);

        function Label(params, asset) {
          var _this = this;

          var glyph = JSON.parse(params.scene.assets[asset.glyph].data);
          var font = new g.BitmapFont({
            src: params.scene.assets[asset.image],
            map: glyph.map,
            defaultGlyphWidth: glyph.width,
            defaultGlyphHeight: glyph.height,
            missingGlyph: glyph.missingGlyph
          });
          _this = _super.call(this, {
            scene: params.scene,
            fontSize: params.fontSize,
            text: params.text,
            width: params.width,
            height: params.height,
            widthAutoAdjust: typeof params.widthAutoAdjust !== 'undefined' ? params.widthAutoAdjust : true,
            textAlign: params.textAlign,
            x: params.x,
            y: params.y,
            opacity: params.opacity,
            font: font
          }) || this;
          return _this;
        }

        return Label;
      }(g.Label);

      var MediumBlack64pxLabel =
      /** @class */
      function (_super) {
        __extends(MediumBlack64pxLabel, _super);

        function MediumBlack64pxLabel(params) {
          return _super.call(this, params, {
            image: 'medium_black_64',
            glyph: 'medium_black_64_glyph'
          }) || this;
        }

        return MediumBlack64pxLabel;
      }(Label);

      exports.MediumBlack64pxLabel = MediumBlack64pxLabel;

      var MediumWhite64pxLabel =
      /** @class */
      function (_super) {
        __extends(MediumWhite64pxLabel, _super);

        function MediumWhite64pxLabel(params) {
          return _super.call(this, params, {
            image: 'medium_white_64',
            glyph: 'medium_white_64_glyph'
          }) || this;
        }

        return MediumWhite64pxLabel;
      }(Label);

      exports.MediumWhite64pxLabel = MediumWhite64pxLabel;

      var BoldBlack128pxLabel =
      /** @class */
      function (_super) {
        __extends(BoldBlack128pxLabel, _super);

        function BoldBlack128pxLabel(params) {
          return _super.call(this, params, {
            image: 'bold_black_128',
            glyph: 'bold_black_128_glyph'
          }) || this;
        }

        return BoldBlack128pxLabel;
      }(Label);

      exports.BoldBlack128pxLabel = BoldBlack128pxLabel;
    }, {}],
    11: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var Messenger =
      /** @class */
      function () {
        function Messenger(scene) {
          var _this = this;

          this.scene = scene;
          this.handlers = [];
          scene.message.add(function (event) {
            return _this.onMessage(event);
          });
        }

        Messenger.prototype.onReceive = function (eventName, handler) {
          this.handlers.push({
            type: eventName,
            f: handler
          });
        };

        Messenger.prototype.send = function (type, data) {
          g.game.raiseEvent(new g.MessageEvent({
            type: type,
            data: data
          }));
        };

        Messenger.prototype.onMessage = function (event) {
          var eventData = event.data;
          this.handlers.forEach(function (handler) {
            if (handler.type === eventData.type) {
              handler.f(eventData.data);
            }
          });
        };

        return Messenger;
      }();

      exports.Messenger = Messenger;
    }, {}],
    12: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var Util_1 = require("../util/Util");

      var akashic_timeline_1 = require("@akashic-extension/akashic-timeline");

      var Label_1 = require("./Label");

      var Player =
      /** @class */
      function (_super) {
        __extends(Player, _super);

        function Player(params) {
          var _this = _super.call(this, {
            scene: params.scene,
            x: params.x,
            y: params.y
          }) || this;

          _this.timeline = new akashic_timeline_1.Timeline(params.scene);
          _this.highTopY = params.y - 10;
          _this.topY = params.y;
          _this.bottomY = params.y + 3;
          _this.disableSound = params.disableSound;
          _this.tori1 = new g.Sprite({
            scene: params.scene,
            src: params.scene.assets['tori']
          });
          _this.tori2 = new g.Sprite({
            scene: params.scene,
            src: params.scene.assets['tori2']
          });
          _this.tori3 = new g.Sprite({
            scene: params.scene,
            src: params.scene.assets['tori3']
          });
          _this.tori4 = new g.Sprite({
            scene: params.scene,
            src: params.scene.assets['tori4']
          });
          _this.tori_tame1 = new g.Sprite({
            scene: params.scene,
            src: params.scene.assets['tori_tame1']
          });
          _this.tori_jump1 = new g.Sprite({
            scene: params.scene,
            src: params.scene.assets['tori_jump1']
          });
          _this.tori_miss1 = new g.Sprite({
            scene: params.scene,
            src: params.scene.assets['tori_miss1']
          });

          _this.append(_this.tori1);

          _this.append(_this.tori2);

          _this.append(_this.tori3);

          _this.append(_this.tori4);

          _this.append(_this.tori_tame1);

          _this.append(_this.tori_jump1);

          _this.append(_this.tori_miss1);

          _this.width = _this.tori1.width;
          _this.height = _this.tori1.height;

          if (params.name) {
            _this.nameLabel = new g.Label({
              scene: _this.scene,
              text: params.name,
              font: new g.DynamicFont({
                game: g.game,
                fontFamily: g.FontFamily.Monospace,
                size: 20
              }),
              fontSize: 20,
              textColor: '#0d0015'
            });
            _this.nameLabel.x = (_this.width - _this.nameLabel.width) / 2;
            _this.nameLabel.y = 0;

            _this.append(_this.nameLabel);
          }

          if (params.isMe) {
            _this.meLabel = new Label_1.MediumBlack64pxLabel({
              scene: _this.scene,
              text: 'あなた',
              fontSize: 20
            });
            _this.meLabel.x = (_this.width - _this.meLabel.width) / 2;
            _this.meLabel.y = _this.nameLabel ? -_this.nameLabel.height : 0;

            _this.append(_this.meLabel);
          }

          _this.greatLabel = new g.Sprite({
            scene: params.scene,
            src: params.scene.assets['great_icon'],
            opacity: 0,
            x: _this.width - 30,
            y: 0
          });
          _this.goodLabel = new g.Sprite({
            scene: params.scene,
            src: params.scene.assets['good_icon'],
            opacity: 0,
            x: _this.width - 30,
            y: 0
          });
          _this.failLabel = new g.Sprite({
            scene: params.scene,
            src: params.scene.assets['fail_icon'],
            opacity: 0,
            x: _this.width - 30,
            y: 0
          }); // this.greatLabel.hide();
          // this.goodLabel.hide();
          // this.failLabel.hide();

          _this.append(_this.greatLabel);

          _this.append(_this.goodLabel);

          _this.append(_this.failLabel);

          _this.modified();

          _this.setStep1();

          return _this;
        }

        Object.defineProperty(Player.prototype, "currentStep", {
          get: function get() {
            return this._currentStep;
          },
          enumerable: true,
          configurable: true
        });

        Player.prototype.actionCount = function () {
          this.timeline.create(this, {
            modified: this.modified,
            destroyed: this.destroyed
          }).moveY(this.bottomY, 100, akashic_timeline_1.Easing.easeInOutExpo).moveY(this.topY, 100, akashic_timeline_1.Easing.easeInOutExpo);
        };

        Player.prototype.setStep1 = function () {
          this._currentStep = 1;
          this.tori1.show();
          this.tori2.hide();
          this.tori3.hide();
          this.tori4.hide();
          this.tori_tame1.hide();
          this.tori_jump1.hide();
          this.tori_miss1.hide();

          if (!this.disableSound) {
            Util_1.Util.playAudio(this.scene, 'peta1');
            Util_1.Util.playAudio(this.scene, 'don');
          }

          this.timeline.create(this, {
            modified: this.modified,
            destroyed: this.destroyed
          }).moveY(this.bottomY, 100, akashic_timeline_1.Easing.easeInOutExpo);
        };

        Player.prototype.setStep2 = function () {
          this._currentStep = 2;
          this.tori1.hide();
          this.tori2.show();
          this.tori3.hide();
          this.tori4.hide();
          this.tori_tame1.hide();
          this.tori_jump1.hide();
          this.tori_miss1.hide();

          if (!this.disableSound) {
            Util_1.Util.playAudio(this.scene, 'peta2');
          }

          this.timeline.create(this, {
            modified: this.modified,
            destroyed: this.destroyed
          }).moveY(this.topY, 100, akashic_timeline_1.Easing.easeInOutExpo);
        };

        Player.prototype.setStep3 = function () {
          this._currentStep = 3;
          this.tori1.hide();
          this.tori2.hide();
          this.tori3.show();
          this.tori4.hide();
          this.tori_tame1.hide();
          this.tori_jump1.hide();
          this.tori_miss1.hide();

          if (!this.disableSound) {
            Util_1.Util.playAudio(this.scene, 'peta1');
            Util_1.Util.playAudio(this.scene, 'don');
          }

          this.timeline.create(this, {
            modified: this.modified,
            destroyed: this.destroyed
          }).moveY(this.bottomY, 100, akashic_timeline_1.Easing.easeInOutExpo);
        };

        Player.prototype.setStep4 = function () {
          this._currentStep = 4;
          this.tori1.hide();
          this.tori2.hide();
          this.tori3.hide();
          this.tori4.show();
          this.tori_tame1.hide();
          this.tori_jump1.hide();
          this.tori_miss1.hide();

          if (!this.disableSound) {
            Util_1.Util.playAudio(this.scene, 'peta2');
          }

          this.timeline.create(this, {
            modified: this.modified,
            destroyed: this.destroyed
          }).moveY(this.topY, 100, akashic_timeline_1.Easing.easeInOutExpo);
        };

        Player.prototype.setTame = function () {
          this.tori1.hide();
          this.tori2.hide();
          this.tori3.hide();
          this.tori4.hide();
          this.tori_tame1.show();
          this.tori_jump1.hide();
          this.tori_miss1.hide();
          this.timeline.create(this, {
            modified: this.modified,
            destroyed: this.destroyed
          }).moveY(this.bottomY, 50, akashic_timeline_1.Easing.easeInOutExpo);
        };

        Player.prototype.setJump = function () {
          this.tori1.hide();
          this.tori2.hide();
          this.tori3.hide();
          this.tori4.hide();
          this.tori_tame1.hide();
          this.tori_jump1.show();
          this.tori_miss1.hide(); // numa_tail だけは disableAudio の例外。再生する

          Util_1.Util.playAudio(this.scene, 'numa_tail');
          this.timeline.create(this, {
            modified: this.modified,
            destroyed: this.destroyed
          }).moveY(this.highTopY, 300, akashic_timeline_1.Easing.easeInOutExpo).moveY(this.topY, 60, akashic_timeline_1.Easing.easeInOutExpo);
        };

        Player.prototype.setMiss = function () {
          if (this.tori_miss1.visible()) {
            return;
          }

          this.tori1.hide();
          this.tori2.hide();
          this.tori3.hide();
          this.tori4.hide();
          this.tori_tame1.hide();
          this.tori_jump1.hide();
          this.tori_miss1.show();

          if (!this.disableSound) {
            Util_1.Util.playAudio(this.scene, 'miss');
          }
        };

        Player.prototype.showFeedbackLabel = function (type) {
          var targetEntity = this.getFeedbackLabelTargetEntity(type);
          this.timeline.create(targetEntity, {
            modified: targetEntity.modified,
            destroyed: targetEntity.destroyed
          }).fadeIn(50, akashic_timeline_1.Easing.easeOutCirc).wait(120).fadeOut(50, akashic_timeline_1.Easing.easeOutCirc);
        };

        Player.prototype.getFeedbackLabelTargetEntity = function (type) {
          switch (type) {
            case 'great':
              return this.greatLabel;

            case 'good':
              return this.goodLabel;

            case 'fail':
              return this.failLabel;
          }
        };

        return Player;
      }(g.E);

      exports.Player = Player;
    }, {
      "../util/Util": 29,
      "./Label": 10,
      "@akashic-extension/akashic-timeline": 5
    }],
    13: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var Messenger_1 = require("./Messenger");

      var PlayerJoiningManager =
      /** @class */
      function () {
        function PlayerJoiningManager(scene) {
          var _this = this;

          this.scene = scene;
          this.onPlayerJoin = new g.Trigger();
          /**
           * 0番目は必ず生主
           * 1番目以降に「参加する」表明したユーザー情報が入っている
           */

          this.players = [];
          g.game.join.addOnce(this.onJoin.bind(this));
          this.messenger = new Messenger_1.Messenger(scene);
          this.messenger.onReceive('join', function (event) {
            console.log('on receive join', event);

            if (!_this.players.some(function (player) {
              return player.id === event.id;
            })) {
              _this.players.push(event);

              _this.onPlayerJoin.fire({
                player: event
              });
            }
          });
          this.messenger.onReceive('getGameMasterUserInfo', function (event) {
            console.log('on getGameMasterUserInfo', event);
            _this.players[0].userId = event.userId;
            _this.players[0].userName = event.userName;
          });
        }

        PlayerJoiningManager.prototype.isGameMaster = function () {
          if (this.players.length === 0) {
            return false;
          }

          return this.players[0].id === g.game.selfId;
        };

        PlayerJoiningManager.prototype.isJoined = function () {
          return this.players.some(function (player) {
            return player.id === g.game.selfId;
          });
        };

        PlayerJoiningManager.prototype.join = function () {
          var _this = this;

          g.game.external.nico.getAccount(function (error, user) {
            console.log('join', g.game.selfId);
            var userId = user ? user.id : g.game.selfId;
            var userName = user ? user.name : g.game.selfId;

            _this.messenger.send('join', {
              id: g.game.selfId,
              userId: userId,
              userName: userName
            });
          });
        };

        PlayerJoiningManager.prototype.getGameMasterUserInfo = function () {
          var _this = this;

          if (!this.players[0] || this.players[0].id !== g.game.selfId) {
            return;
          }

          g.game.external.nico.getAccount(function (error, user) {
            console.log('getGameMasterUserInfo', g.game.selfId);
            var userId = user ? user.id : g.game.selfId;
            var userName = user ? user.name : g.game.selfId;

            _this.messenger.send('getGameMasterUserInfo', {
              userId: userId,
              userName: userName
            });
          });
        };

        PlayerJoiningManager.prototype.me = function () {
          var me = this.players.filter(function (player) {
            return player.id === g.game.selfId;
          });

          if (!me) {
            return;
          }

          return me[0];
        };
        /**
         * このハンドラは、ニコ生においては生主のときのみ呼ばれる
         * @param event
         */


        PlayerJoiningManager.prototype.onJoin = function (event) {
          var _this = this;

          if (event.player.id !== g.game.selfId) {
            return;
          } // this.messenger.send('join', {
          //   id: g.game.selfId,
          //   userId: null,
          //   userName: null
          // });


          g.game.external.nico.getAccount(function (error, user) {
            console.log('master join', g.game.selfId);
            var userId = user ? user.id : g.game.selfId;
            var userName = user ? user.name : g.game.selfId;

            _this.messenger.send('join', {
              id: g.game.selfId,
              userId: userId,
              userName: userName
            });
          });
        };

        return PlayerJoiningManager;
      }();

      exports.PlayerJoiningManager = PlayerJoiningManager;
    }, {
      "./Messenger": 11
    }],
    14: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var RoundedFilledRect =
      /** @class */
      function (_super) {
        __extends(RoundedFilledRect, _super);

        function RoundedFilledRect(params) {
          var _this = _super.call(this, {
            scene: params.scene,
            width: params.width,
            height: params.height,
            x: params.x,
            y: params.y
          }) || this;

          _this.topBottomFilledRect = new g.FilledRect({
            scene: params.scene,
            width: params.width - params.borderRadius * 2,
            height: params.height,
            x: params.borderRadius,
            y: 0,
            cssColor: params.cssColor
          });
          _this.leftRightFilledRect = new g.FilledRect({
            scene: params.scene,
            width: params.width,
            height: params.height - params.borderRadius * 2,
            x: 0,
            y: params.borderRadius,
            cssColor: params.cssColor
          });
          var size = params.borderRadius * 2;
          _this.leftTopCircle = new g.Sprite({
            scene: params.scene,
            src: params.scene.assets[params.circleAssetId],
            width: size,
            height: size,
            srcWidth: params.circleAssetSize,
            srcHeight: params.circleAssetSize,
            x: 0,
            y: 0
          });
          _this.rightTopCircle = new g.Sprite({
            scene: params.scene,
            src: params.scene.assets[params.circleAssetId],
            width: size,
            height: size,
            srcWidth: params.circleAssetSize,
            srcHeight: params.circleAssetSize,
            x: params.width - size,
            y: 0
          });
          _this.rightBottomCircle = new g.Sprite({
            scene: params.scene,
            src: params.scene.assets[params.circleAssetId],
            width: size,
            height: size,
            srcWidth: params.circleAssetSize,
            srcHeight: params.circleAssetSize,
            x: params.width - size,
            y: params.height - size
          });
          _this.leftBottomCircle = new g.Sprite({
            scene: params.scene,
            src: params.scene.assets[params.circleAssetId],
            width: size,
            height: size,
            srcWidth: params.circleAssetSize,
            srcHeight: params.circleAssetSize,
            x: 0,
            y: params.height - size
          });

          _this.append(_this.topBottomFilledRect);

          _this.append(_this.leftRightFilledRect);

          _this.append(_this.leftTopCircle);

          _this.append(_this.rightTopCircle);

          _this.append(_this.rightBottomCircle);

          _this.append(_this.leftBottomCircle);

          return _this;
        }

        Object.defineProperty(RoundedFilledRect.prototype, "cssColor", {
          set: function set(value) {
            this.topBottomFilledRect.cssColor = value;
            this.leftRightFilledRect.cssColor = value;
            this.topBottomFilledRect.modified();
            this.leftRightFilledRect.modified();
            this.leftTopCircle.invalidate();
            this.rightTopCircle.invalidate();
            this.rightBottomCircle.invalidate();
            this.leftBottomCircle.invalidate();
          },
          enumerable: true,
          configurable: true
        });
        return RoundedFilledRect;
      }(g.E);

      exports.RoundedFilledRect = RoundedFilledRect;
    }, {}],
    15: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var RoundedFilledRect_1 = require("./RoundedFilledRect");

      var Label_1 = require("./Label");

      var StartButton =
      /** @class */
      function (_super) {
        __extends(StartButton, _super);

        function StartButton(params) {
          var _this = _super.call(this, {
            scene: params.scene,
            width: 180,
            height: 50,
            touchable: true,
            local: true
          }) || this;

          _this.redBackground = new RoundedFilledRect_1.RoundedFilledRect({
            scene: _this.scene,
            width: _this.width,
            height: _this.height,
            x: 0,
            y: 0,
            borderRadius: 20,
            cssColor: '#c33',
            circleAssetId: 'red_circle_32',
            circleAssetSize: 32
          });

          _this.append(_this.redBackground);

          _this.text = new Label_1.MediumWhite64pxLabel({
            scene: _this.scene,
            text: 'スタート',
            fontSize: 28
          });
          _this.text.x = (_this.width - _this.text.width) / 2;
          _this.text.y = (_this.height - _this.text.height) / 2;

          _this.append(_this.text);

          return _this;
        }

        return StartButton;
      }(g.E);

      exports.StartButton = StartButton;
    }, {
      "./Label": 10,
      "./RoundedFilledRect": 14
    }],
    16: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var RoundedFilledRect_1 = require("./RoundedFilledRect");

      var Label_1 = require("./Label");

      var StopJoinButton =
      /** @class */
      function (_super) {
        __extends(StopJoinButton, _super);

        function StopJoinButton(params) {
          var _this = _super.call(this, {
            scene: params.scene,
            width: 180,
            height: 50,
            touchable: true,
            local: true
          }) || this;

          _this.background = new RoundedFilledRect_1.RoundedFilledRect({
            scene: _this.scene,
            width: _this.width,
            height: _this.height,
            x: 0,
            y: 0,
            borderRadius: 20,
            cssColor: '#c33',
            circleAssetId: 'red_circle_32',
            circleAssetSize: 32
          });

          _this.append(_this.background);

          _this.text = new Label_1.MediumWhite64pxLabel({
            scene: _this.scene,
            text: '参加締め切り',
            fontSize: 28
          });
          _this.text.x = (_this.width - _this.text.width) / 2;
          _this.text.y = (_this.height - _this.text.height) / 2;

          _this.append(_this.text);

          return _this;
        }

        return StopJoinButton;
      }(g.E);

      exports.StopJoinButton = StopJoinButton;
    }, {
      "./Label": 10,
      "./RoundedFilledRect": 14
    }],
    17: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var Player_1 = require("./Player");

      var akashic_timeline_1 = require("@akashic-extension/akashic-timeline");

      var Label_1 = require("./Label");

      var TeachingSlide =
      /** @class */
      function (_super) {
        __extends(TeachingSlide, _super);

        function TeachingSlide(params) {
          var _this = _super.call(this, {
            scene: params.scene
          }) || this;

          _this.timeline = new akashic_timeline_1.Timeline(_this.scene);
          _this.text1 = new Label_1.MediumBlack64pxLabel({
            scene: _this.scene,
            text: '掛け声で',
            fontSize: 20
          });
          _this.text2 = new Label_1.MediumBlack64pxLabel({
            scene: _this.scene,
            text: '下スライドして',
            fontSize: 20
          });
          _this.yubi = new g.Label({
            scene: _this.scene,
            text: '👆',
            font: new g.DynamicFont({
              game: g.game,
              fontFamily: g.FontFamily.Monospace,
              size: 60
            }),
            fontSize: 60
          }); // 一番長いのをコンテナの幅に

          _this.width = _this.text2.width;
          _this.text1.y = 0;
          _this.text1.x = (_this.width - _this.text1.width) / 2;
          _this.text2.y = _this.text1.height;
          _this.text2.x = (_this.width - _this.text2.width) / 2;
          _this.yubi.y = _this.text2.y + _this.text2.height;
          _this.yubi.x = (_this.width - _this.yubi.width) / 2;
          _this.tori = new Player_1.Player({
            scene: _this.scene,
            disableSound: true,
            x: 0,
            y: _this.yubi.y + _this.yubi.height - 30
          });

          _this.append(_this.tori);

          _this.append(_this.text1);

          _this.append(_this.text2);

          _this.append(_this.yubi);

          return _this;
        }

        TeachingSlide.prototype.slideDown = function () {
          var _this = this;

          this.timeline.create(this.yubi, {
            modified: this.yubi.modified,
            destroyed: this.yubi.destroyed
          }).moveBy(0, 80, 50).con().call(function () {
            _this.tori.setTame();

            _this.text1.text = '掛け声で';
            _this.text2.text = '下スライドして';

            _this.text1.invalidate();

            _this.text2.invalidate();

            _this.text1.x = (_this.width - _this.text1.width) / 2;
            _this.text2.x = (_this.width - _this.text2.width) / 2;
          });
        };

        TeachingSlide.prototype.slideUp = function () {
          var _this = this;

          this.timeline.create(this.yubi, {
            modified: this.yubi.modified,
            destroyed: this.yubi.destroyed
          }).moveBy(0, -80, 50).con().call(function () {
            _this.tori.setJump();

            _this.text1.text = '上スライドで';
            _this.text2.text = 'ジャンプ';

            _this.text1.invalidate();

            _this.text2.invalidate();

            _this.text1.x = (_this.width - _this.text1.width) / 2;
            _this.text2.x = (_this.width - _this.text2.width) / 2;
          });
        };

        TeachingSlide.prototype.startAnimation = function () {// const tapDuration = 200;
          // const interval = 700;
          // this.timeline.create(this.yubi, {
          //   modified: this.yubi.modified,
          //   destroyed: this.yubi.destroyed,
          //   loop: true
          // })
          //   .moveBy(0, 80, tapDuration)
          //   .wait(interval - tapDuration)
          //   .con()
          //   .call(() => {
          //     this.tori.setTame();
          //     this.text1.text = '掛け声で';
          //     this.text2.text = '下スライドして';
          //     this.text1.invalidate();
          //     this.text2.invalidate();
          //     this.text1.x = (this.width - this.text1.width) / 2;
          //     this.text2.x = (this.width - this.text2.width) / 2;
          //   })
          //   .wait(interval)
          //   .moveBy(0, -80, tapDuration)
          //   .wait(interval - tapDuration)
          //   .con()
          //   .call(() => {
          //     this.tori.setJump();
          //     this.text1.text = '上スライドで';
          //     this.text2.text = 'ジャンプ';
          //     this.text1.invalidate();
          //     this.text2.invalidate();
          //     this.text1.x = (this.width - this.text1.width) / 2;
          //     this.text2.x = (this.width - this.text2.width) / 2;
          //   })
          //   .wait(interval);
        };

        return TeachingSlide;
      }(g.E);

      exports.TeachingSlide = TeachingSlide;
    }, {
      "./Label": 10,
      "./Player": 12,
      "@akashic-extension/akashic-timeline": 5
    }],
    18: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var Player_1 = require("./Player");

      var akashic_timeline_1 = require("@akashic-extension/akashic-timeline");

      var Label_1 = require("./Label");

      var TeachingTap =
      /** @class */
      function (_super) {
        __extends(TeachingTap, _super);

        function TeachingTap(params) {
          var _this = _super.call(this, {
            scene: params.scene
          }) || this;

          _this.timeline = new akashic_timeline_1.Timeline(_this.scene);
          _this.text1 = new Label_1.MediumBlack64pxLabel({
            scene: _this.scene,
            text: '曲に合わせて',
            fontSize: 20
          });
          _this.text2 = new Label_1.MediumBlack64pxLabel({
            scene: _this.scene,
            text: 'タップ',
            fontSize: 20
          });
          _this.yubi = new g.Label({
            scene: _this.scene,
            text: '👆',
            font: new g.DynamicFont({
              game: g.game,
              fontFamily: g.FontFamily.Monospace,
              size: 60
            }),
            fontSize: 60
          }); // 一番長いのをコンテナの幅に

          _this.width = _this.text1.width;
          _this.text1.y = 0;
          _this.text1.x = (_this.width - _this.text1.width) / 2;
          _this.text2.y = _this.text1.height;
          _this.text2.x = (_this.width - _this.text2.width) / 2;
          _this.yubi.y = _this.text2.y + _this.text2.height;
          _this.yubi.x = (_this.width - _this.yubi.width) / 2;
          _this.player = new Player_1.Player({
            scene: _this.scene,
            disableSound: true,
            x: 0,
            y: _this.yubi.y + _this.yubi.height - 30
          });

          _this.append(_this.player);

          _this.append(_this.text1);

          _this.append(_this.text2);

          _this.append(_this.yubi);

          return _this;
        }

        TeachingTap.prototype.action = function (beatIndex) {
          var _this = this;

          switch (beatIndex) {
            case 0:
            case 2:
              this.player.setStep1();
              this.timeline.create(this.yubi, {
                modified: this.yubi.modified,
                destroyed: this.yubi.destroyed
              }).rotateBy(-60, 50).con().moveBy(0, 10, 50);
              this.scene.setTimeout(function () {
                _this.player.setStep2();

                _this.timeline.create(_this.yubi, {
                  modified: _this.yubi.modified,
                  destroyed: _this.yubi.destroyed
                }).rotateBy(60, 50).con().moveBy(0, -10, 50);
              }, 150);
              break;

            case 1:
            case 3:
              this.player.setStep3();
              this.timeline.create(this.yubi, {
                modified: this.yubi.modified,
                destroyed: this.yubi.destroyed
              }).rotateBy(-60, 50).con().moveBy(0, 10, 50);
              this.scene.setTimeout(function () {
                _this.player.setStep4();

                _this.timeline.create(_this.yubi, {
                  modified: _this.yubi.modified,
                  destroyed: _this.yubi.destroyed
                }).rotateBy(60, 50).con().moveBy(0, -10, 50);
              }, 150);
              break;
          }
        };

        TeachingTap.prototype.startAnimation = function () {// this.timeline = new Timeline(this.scene);
          // const tapDuration = 100;
          // const interval = 500;
          // this.timeline.create(this.yubi, {
          //   modified: this.yubi.modified,
          //   destroyed: this.yubi.destroyed,
          //   loop: true
          // })
          //   .rotateBy(-60, tapDuration)
          //   .con()
          //   .moveBy(0, 10, tapDuration)
          //   .wait(interval - tapDuration)
          //   .con()
          //   .call(() => this.player.setStep2())
          //   .wait(interval)
          //   .rotateBy(60, tapDuration)
          //   .con()
          //   .moveBy(0, -10, tapDuration)
          //   .wait(interval - tapDuration)
          //   .con()
          //   .call(() => this.player.setStep3())
          //   .wait(interval)
          //   .rotateBy(-60, tapDuration)
          //   .con()
          //   .moveBy(0, 10, tapDuration)
          //   .wait(interval - tapDuration)
          //   .con()
          //   .call(() => this.player.setStep4())
          //   .wait(interval)
          //   .rotateBy(60, tapDuration)
          //   .con()
          //   .moveBy(0, -10, tapDuration)
          //   .wait(interval - tapDuration)
          //   .con()
          //   .call(() => this.player.setStep1())
          //   .wait(interval);
        };

        return TeachingTap;
      }(g.E);

      exports.TeachingTap = TeachingTap;
    }, {
      "./Label": 10,
      "./Player": 12,
      "@akashic-extension/akashic-timeline": 5
    }],
    19: [function (require, module, exports) {
      "use strict";

      var MainScene_1 = require("./scene/MainScene");

      function main(param) {
        mockNicoPlugin();
        var scene = new MainScene_1.MainScene({
          game: g.game,
          assetIds: ['opening', 'medium_black_64', 'medium_black_64_glyph', 'medium_white_64', 'medium_white_64_glyph', 'bold_black_128', 'bold_black_128_glyph', 'lightblue_circle_32', 'red_circle_32', 'white_circle_32', 'gray_circle_32', 'tori', 'tori2', 'tori3', 'tori4', 'tori_tame1', 'tori_jump1', 'tori_miss1', 'asiato', 'tutorial1', 'tutorial2', 'tutorial3', 'music1', 'music2', 'music3', 'music4', 'music5', 'music6', 'music7', 'music8', 'music9', 'music10', 'music11', 'music12', 'music13', 'music14', 'music15', 'music16', 'music17', 'music18', 'music19', 'music20', 'music21', 'music22', 'music23', 'music24', 'music25', 'music26', 'music27', 'music28', 'music29', 'music30', 'music31', 'music32', 'music33', 'music34', 'music35', 'music36', 'music37', 'music38', 'music39', 'music40', 'music41', 'music42', 'music43', 'music44', 'music45', 'music46', 'music47', 'music48', 'music49', 'numa_head', 'numa_tail', 'peta1', 'peta2', 'miss', 'don', 'pi', 'great_icon', 'good_icon', 'fail_icon', 'pi2', 'jingle_heibon', 'jingle_highlevel', 'heibon', 'highlevel', 'perfect']
        });
        g.game.pushScene(scene);
      }

      function mockNicoPlugin() {
        if (g.game.external.nico) {
          return;
        }

        g.game.external.nico = {
          getAccount: function getAccount(callback) {
            if (g.game.selfId == null) {
              callback(new Error('not found'));
              return;
            }

            var isPremium = Number(g.game.selfId) % 2 === 0;
            callback(null, {
              id: g.game.selfId,
              name: g.game.selfId,
              premium: isPremium ? 'premium' : null
            });
          }
        };
      }

      module.exports = main;
    }, {
      "./scene/MainScene": 21
    }],
    20: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var SubScene_1 = require("./SubScene");

      var Player_1 = require("../component/Player");

      var GameManager_1 = require("../component/GameManager");

      var GestureHandler_1 = require("../component/GestureHandler");

      var Messenger_1 = require("../component/Messenger");

      var akashic_timeline_1 = require("@akashic-extension/akashic-timeline");

      var GameBackground_1 = require("../component/GameBackground");

      var Util_1 = require("../util/Util");

      var NonbiriTouringScore_1 = require("../score/NonbiriTouringScore");

      var GameSubScene =
      /** @class */
      function (_super) {
        __extends(GameSubScene, _super);

        function GameSubScene(_scene, playerJoiningManager) {
          var _this = _super.call(this, _scene) || this;

          _this.playerJoiningManager = playerJoiningManager;
          _this.onGameEnd = new g.Trigger();
          _this.players = {};
          _this.pipyakoCount = 0;
          _this.messenger = new Messenger_1.Messenger(_scene);
          return _this;
        }

        GameSubScene.prototype.init = function () {
          var _this = this;

          this.timeline = new akashic_timeline_1.Timeline(this.scene);
          this.manager = new GameManager_1.GameManager({
            scene: this.scene,
            score: NonbiriTouringScore_1.default
          });
          this.background = new GameBackground_1.GameBackground({
            scene: this.scene
          });
          this.playersLayer = new g.E({
            scene: this.scene
          });
          this.gestureHandler = new GestureHandler_1.GestureHandler({
            scene: this.scene
          });
          this.gestureHandler.onTap.add(function () {
            // gestureHandler は local
            var beatIndex = _this.manager.action(0
            /* Click */
            );

            _this.messenger.send('tap', {
              playerId: g.game.selfId,
              beatIndex: beatIndex
            });
          });
          this.gestureHandler.onTapUp.add(function () {
            // local
            _this.messenger.send('tapUp', {
              playerId: g.game.selfId
            });
          });
          this.gestureHandler.onSlideDown.add(function () {
            // local
            _this.manager.action(1
            /* SlideDown */
            );

            _this.messenger.send('slideDown', {
              playerId: g.game.selfId
            });
          });
          this.gestureHandler.onSlideUp.add(function () {
            // local
            _this.manager.action(2
            /* SlideUp */
            );

            _this.messenger.send('slideUp', {
              playerId: g.game.selfId
            });
          });
          this.fadeOutOverlay = new g.FilledRect({
            scene: this.scene,
            cssColor: '#000000',
            width: this.scene.game.width,
            height: this.scene.game.height,
            opacity: 0
          });
          this.append(this.background);
          this.append(this.manager);
          this.append(this.playersLayer); // this.append(this.actionResultLabel);

          this.append(this.fadeOutOverlay);
          this.append(this.gestureHandler);
          this.hideContent();
          this.messenger.onReceive('tap', function (event) {
            var targetPlayer = _this.players[event.playerId];

            if (!targetPlayer) {
              return;
            }

            switch (event.beatIndex) {
              case 0:
              case 2:
                targetPlayer.setStep1();
                break;

              case 1:
              case 3:
                targetPlayer.setStep3();
                break;
            }
          });
          this.messenger.onReceive('tapUp', function (event) {
            var targetPlayer = _this.players[event.playerId];

            if (!targetPlayer) {
              return;
            }

            switch (targetPlayer.currentStep) {
              case 1:
                targetPlayer.setStep2();
                break;

              case 3:
                targetPlayer.setStep4();
                break;
            }
          });
          this.messenger.onReceive('slideDown', function (event) {
            var targetPlayer = _this.players[event.playerId];

            if (!targetPlayer) {
              return;
            }

            targetPlayer.setTame();
          });
          this.messenger.onReceive('slideUp', function (event) {
            var targetPlayer = _this.players[event.playerId];

            if (!targetPlayer) {
              return;
            }

            targetPlayer.setJump();
          });
          this.manager.onCount.add(function (event) {
            if (event.isLast) {
              Object.keys(_this.players).forEach(function (k) {
                _this.players[k].setStep4();
              });
            } else {
              Object.keys(_this.players).forEach(function (k) {
                _this.players[k].actionCount();
              });
            }
          });
          this.manager.onBeatActionStatusFixed.add(function (event) {
            // local
            var myPlayer = _this.players[_this.scene.game.selfId];

            if (!myPlayer) {
              return;
            } // console.log('onBeatActionStatusFixed', event);


            switch (event.status) {
              case 1
              /* Great */
              :
                myPlayer.showFeedbackLabel('great');
                break;

              case 2
              /* Good */
              :
                myPlayer.showFeedbackLabel('good');
                break;

              case 3
              /* Fail */
              :
                myPlayer.showFeedbackLabel('fail');

                _this.messenger.send('miss', {
                  playerId: g.game.selfId
                });

                break;
            }
          });
          this.manager.onLastSomeMeasures.add(function (event) {
            _this.timeline.create(_this.fadeOutOverlay, {
              modified: _this.fadeOutOverlay.modified,
              destroyed: _this.fadeOutOverlay.destroyed
            }).to({
              opacity: 1
            }, 1000 * event.age / g.game.fps).wait(1500).call(function () {
              _this.onGameEnd.fire({
                states: _this.manager.getStates()
              });
            });
          });
          this.manager.onBeat.add(function (event) {
            // beat
            _this.background.step(_this.calculateStep(event.action));
          });
          this.messenger.onReceive('miss', function (event) {
            var targetPlayer = _this.players[event.playerId];

            if (!targetPlayer) {
              return;
            }

            targetPlayer.setMiss();
          });
        };

        GameSubScene.prototype.initPlayers = function () {
          var _this = this;

          if (Util_1.Util.isAtsumaruEnv()) {
            var player = new Player_1.Player({
              scene: this.scene,
              id: this.scene.game.selfId,
              x: 300,
              y: 100,
              isMe: true
            });
            this.players[this.scene.game.selfId] = player;
            this.playersLayer.append(player);
          } else {
            this.playerJoiningManager.players.forEach(function (p, index) {
              var player = new Player_1.Player({
                scene: _this.scene,
                id: p.id,
                name: p.userName,
                x: 100 + index * 100,
                y: 100,
                isMe: p.id === _this.scene.game.selfId
              });
              _this.players[p.id] = player;

              _this.playersLayer.append(player);
            });
          }
        };

        GameSubScene.prototype.showContent = function () {
          this.background.show();
          this.playersLayer.show();
          this.manager.show();
          this.gestureHandler.show();
          this.fadeOutOverlay.show();
        };

        GameSubScene.prototype.startContent = function () {
          this.manager.start();
        };

        GameSubScene.prototype.onUpdate = function () {//
        };

        GameSubScene.prototype.stopContent = function () {//
        };

        GameSubScene.prototype.hideContent = function () {
          this.background.hide();
          this.playersLayer.hide();
          this.manager.hide();
          this.gestureHandler.hide();
          this.fadeOutOverlay.hide();
        };

        GameSubScene.prototype.calculateStep = function (beatAction) {
          if (this.pipyakoCount > 0) {
            this.pipyakoCount++;
          }

          if (beatAction === 3
          /* PiPyako */
          ) {
              this.pipyakoCount = 1;
              return 8;
            }

          if (this.pipyakoCount === 3) {
            return 2;
          }

          if (this.pipyakoCount === 4) {
            this.pipyakoCount = 0;
            return 24;
          }

          if (beatAction === 2
          /* Normal */
          ) {
              return 8;
            }

          return 0;
        };

        return GameSubScene;
      }(SubScene_1.SubScene);

      exports.GameSubScene = GameSubScene;
    }, {
      "../component/GameBackground": 6,
      "../component/GameManager": 7,
      "../component/GestureHandler": 8,
      "../component/Messenger": 11,
      "../component/Player": 12,
      "../score/NonbiriTouringScore": 26,
      "../util/Util": 29,
      "./SubScene": 23,
      "@akashic-extension/akashic-timeline": 5
    }],
    21: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      }); // import {TitleSubScene} from './TitleSubScene';

      var GameParameters_1 = require("../util/GameParameters"); // import {GameOverSubScene} from './GameOverSubScene';


      var GameSubScene_1 = require("./GameSubScene");

      var TitleSubScene_1 = require("./TitleSubScene");

      var WaitingRoomSubScene_1 = require("./WaitingRoomSubScene");

      var PlayerJoiningManager_1 = require("../component/PlayerJoiningManager");

      var ResultSubScene_1 = require("./ResultSubScene");

      var Util_1 = require("../util/Util");

      var MainScene =
      /** @class */
      function (_super) {
        __extends(MainScene, _super);

        function MainScene(params) {
          var _this = _super.call(this, params) || this;

          _this.playerJoiningManager = new PlayerJoiningManager_1.PlayerJoiningManager(_this);

          _this.loaded.add(function () {
            return _this._onLoad();
          });

          return _this;
        }

        MainScene.prototype._onLoad = function () {
          var _this = this;

          if (this.playerJoiningManager.isGameMaster()) {
            this.playerJoiningManager.getGameMasterUserInfo();
          }

          g.game.vars.gameState = {
            score: 0
          }; // loaded完了後、OperationEventを処理するため1 tick遅延させる

          this.update.addOnce(function () {
            // console.log("scene.update: parameters:" + parameters + ".");
            if (_this.gameParameters) {
              GameParameters_1.GameParameters.init(_this.gameParameters);
            } else {
              GameParameters_1.GameParameters.init({});
            }

            _this._onInitialUpdate();

            return true;
          });
          this.message.add(function (e) {
            // console.log("scene.message: e:" + JSON.stringify(e) + ".");
            if (e.data.type === 'start') {
              _this.gameParameters = e.data.parameters;
            }

            return true;
          });
        };

        MainScene.prototype._onInitialUpdate = function () {
          var _this = this;

          if (GameParameters_1.GameParameters.launchType !== GameParameters_1.LaunchType.RANKING) {
            // ランキング以外のとき背景設定
            var background = new g.FilledRect({
              scene: this,
              cssColor: '#ffffff',
              width: this.game.width,
              height: this.game.height
            });
            this.append(background);
          }

          this.titleSubScene = new TitleSubScene_1.TitleSubScene(this);
          this.titleSubScene.init();
          this.titleSubScene.onTitleSceneEnd.add(function () {
            return _this.onTitleSceneEnd();
          });
          this.append(this.titleSubScene);
          this.waitingRoomSubScene = new WaitingRoomSubScene_1.WaitingRoomSubScene(this, this.playerJoiningManager);
          this.waitingRoomSubScene.init();
          this.waitingRoomSubScene.onSceneEnd.add(function () {
            return _this.onWaitingRoomSceneEnd();
          });
          this.append(this.waitingRoomSubScene);
          this.gameSubScene = new GameSubScene_1.GameSubScene(this, this.playerJoiningManager);
          this.gameSubScene.init();
          this.gameSubScene.onGameEnd.add(function (event) {
            return _this.onGameEnd(event);
          });
          this.append(this.gameSubScene);
          this.resultSubScene = new ResultSubScene_1.ResultSubScene(this, this.playerJoiningManager);
          this.resultSubScene.init();
          this.append(this.resultSubScene);
          this.playerJoiningManager.join(); // this.resultSubScene.setResult([
          // BeatActionStatus.Waiting,
          // BeatActionStatus.Waiting,
          // BeatActionStatus.Great,
          // BeatActionStatus.Good,
          // BeatActionStatus.Good,
          // BeatActionStatus.Good,
          // BeatActionStatus.Great,
          // BeatActionStatus.Good,
          // BeatActionStatus.Good,
          // BeatActionStatus.Fail,
          // BeatActionStatus.Fail,
          // BeatActionStatus.Fail,
          // BeatActionStatus.Fail,
          // BeatActionStatus.Fail,
          // BeatActionStatus.Fail,
          // BeatActionStatus.Great,
          // BeatActionStatus.Great,
          // BeatActionStatus.Great,
          // BeatActionStatus.Great
          // ]);
          // this.changeSubscene(this.resultSubScene);
          // this.changeSubscene(this.gameSubScene);
          // this.changeSubscene(this.titleSubScene);
          // this.changeSubscene(this.waitingRoomSubScene);

          if (Util_1.Util.isAtsumaruEnv()) {
            this.changeSubscene(this.titleSubScene);
          }

          this.playerJoiningManager.onPlayerJoin.addOnce(function () {// this.changeSubscene(this.titleSubScene);
          });
          this.update.add(function () {
            return _this.onUpdate(_this);
          });
        };

        MainScene.prototype.onUpdate = function (scene) {
          this.currentSubScene && this.currentSubScene.onUpdate();
          return false;
        };
        /**
         * currentSubsceneをワイプなしで変更する
         */


        MainScene.prototype.changeSubscene = function (_next) {
          if (this.currentSubScene) {
            this.currentSubScene.stopContent();
            this.currentSubScene.hideContent();
          }

          this.currentSubScene = _next;
          this.currentSubScene.showContent();
          this.currentSubScene.startContent();
        };

        MainScene.prototype.onGameEnd = function (event) {
          this.resultSubScene.setResult(event.states);
          this.changeSubscene(this.resultSubScene);
        };

        MainScene.prototype.onTitleSceneEnd = function () {
          this.changeSubscene(this.waitingRoomSubScene);
        };

        MainScene.prototype.onWaitingRoomSceneEnd = function () {
          this.gameSubScene.initPlayers();
          this.changeSubscene(this.gameSubScene);
        };

        return MainScene;
      }(g.Scene);

      exports.MainScene = MainScene;
    }, {
      "../component/PlayerJoiningManager": 13,
      "../util/GameParameters": 28,
      "../util/Util": 29,
      "./GameSubScene": 20,
      "./ResultSubScene": 22,
      "./TitleSubScene": 24,
      "./WaitingRoomSubScene": 25
    }],
    22: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var SubScene_1 = require("./SubScene");

      var RoundedFilledRect_1 = require("../component/RoundedFilledRect");

      var Label_1 = require("../component/Label");

      var Messenger_1 = require("../component/Messenger");

      var Util_1 = require("../util/Util");

      var HyoukaStamp;

      (function (HyoukaStamp) {
        HyoukaStamp[HyoukaStamp["Perfect"] = 0] = "Perfect";
        HyoukaStamp[HyoukaStamp["HighLevel"] = 1] = "HighLevel";
        HyoukaStamp[HyoukaStamp["DemoHeibon"] = 2] = "DemoHeibon";
        HyoukaStamp[HyoukaStamp["Heibon"] = 3] = "Heibon";
      })(HyoukaStamp = exports.HyoukaStamp || (exports.HyoukaStamp = {}));

      var ResultSubScene =
      /** @class */
      function (_super) {
        __extends(ResultSubScene, _super);

        function ResultSubScene(_scene, playerJoiningManager) {
          var _this = _super.call(this, _scene) || this;

          _this.playerJoiningManager = playerJoiningManager;
          _this.onTitleSceneEnd = new g.Trigger();
          _this.allResults = [];
          _this.messenger = new Messenger_1.Messenger(_scene);
          return _this;
        }

        ResultSubScene.prototype.init = function () {
          var _this = this;

          this.background = new g.FilledRect({
            scene: this.scene,
            cssColor: '#000000',
            width: this.scene.game.width,
            height: this.scene.game.height
          });
          this.append(this.background);
          this.titleBackground = new RoundedFilledRect_1.RoundedFilledRect({
            scene: this.scene,
            width: 400,
            height: 50,
            x: (this.scene.game.width - 400) / 2,
            y: 40,
            borderRadius: 25,
            cssColor: '#ffffff',
            circleAssetId: 'white_circle_32',
            circleAssetSize: 32
          });
          this.append(this.titleBackground);
          this.titleLabel = new Label_1.MediumBlack64pxLabel({
            scene: this.scene,
            text: 'みんなの声',
            fontSize: 24
          });
          this.titleLabel.x = (this.scene.game.width - this.titleLabel.width) / 2;
          this.titleLabel.y = 54;
          this.append(this.titleLabel);
          this.hyoukaText = new Label_1.MediumWhite64pxLabel({
            scene: this.scene,
            text: '',
            fontSize: 18
          });
          this.hyoukaText.x = 140;
          this.hyoukaText.y = 140;
          this.append(this.hyoukaText);
          this.hyoukaStampHighLevelText = new g.Sprite({
            scene: this.scene,
            src: this.scene.assets['highlevel']
          });
          this.hyoukaStampHighLevelText.x = this.scene.game.width - this.hyoukaStampHighLevelText.width - 10;
          this.hyoukaStampHighLevelText.y = this.scene.game.height - this.hyoukaStampHighLevelText.height - 10;
          this.append(this.hyoukaStampHighLevelText);
          this.hyoukaPerfectText = new g.Sprite({
            scene: this.scene,
            src: this.scene.assets['perfect']
          });
          this.hyoukaPerfectText.x = this.scene.game.width - this.hyoukaStampHighLevelText.width - 40;
          this.hyoukaPerfectText.y = this.scene.game.height - this.hyoukaPerfectText.height - this.hyoukaStampHighLevelText.height + 10;
          this.append(this.hyoukaPerfectText);
          this.hyoukaStampHeibonText = new g.Sprite({
            scene: this.scene,
            src: this.scene.assets['heibon']
          });
          this.hyoukaStampHeibonText.x = this.scene.game.width - this.hyoukaStampHeibonText.width - 10;
          this.hyoukaStampHeibonText.y = this.scene.game.height - this.hyoukaStampHeibonText.height - 10;
          this.append(this.hyoukaStampHeibonText);
          this.hyoukaStampDemoText = new Label_1.MediumWhite64pxLabel({
            scene: this.scene,
            text: 'でも...',
            fontSize: 18
          });
          this.hyoukaStampDemoText.x = this.scene.game.width - this.hyoukaStampDemoText.width - 10 - this.hyoukaStampHeibonText.width;
          this.hyoukaStampDemoText.y = this.scene.game.height - this.hyoukaStampHeibonText.height - 10;
          this.append(this.hyoukaStampDemoText);
          this.hideContent();
          this.messenger.onReceive('result', function (result) {
            _this.allResults.push(result);
          });
        };

        ResultSubScene.prototype.setResult = function (states) {
          this.resultStates = states;
          this.hyouka = this.calculateHyouka(states); // console.log(states, this.hyouka);

          var me = this.playerJoiningManager.me();

          if (me) {
            this.messenger.send('result', {
              playerId: me.id,
              playerName: me.userName,
              states: this.resultStates,
              points: this.hyouka.points,
              hyouka: {
                stamp: this.hyouka.stamp
              }
            });
          }
        };

        ResultSubScene.prototype.showContent = function () {
          this.background.show();
          this.hyoukaText.text = this.hyouka.message;
          this.hyoukaText.invalidate();
        };

        ResultSubScene.prototype.startContent = function () {
          var _this = this;

          this.scene.setTimeout(function () {
            _this.titleBackground.show();

            _this.titleLabel.show();

            Util_1.Util.playAudio(_this.scene, 'pi2');
          }, 1000);
          this.scene.setTimeout(function () {
            _this.hyoukaText.show();

            Util_1.Util.playAudio(_this.scene, 'peta2');
          }, 2500);
          this.scene.setTimeout(function () {
            if (_this.hyouka.stamp === HyoukaStamp.Perfect) {
              _this.hyoukaStampHighLevelText.show();

              _this.hyoukaPerfectText.show();

              Util_1.Util.playAudio(_this.scene, 'jingle_highlevel');
            } else if (_this.hyouka.stamp === HyoukaStamp.HighLevel) {
              _this.hyoukaStampHighLevelText.show();

              Util_1.Util.playAudio(_this.scene, 'jingle_highlevel');
            } else if (_this.hyouka.stamp === HyoukaStamp.DemoHeibon) {
              _this.hyoukaStampHeibonText.show();

              _this.hyoukaStampDemoText.show();

              Util_1.Util.playAudio(_this.scene, 'jingle_heibon');
            } else {
              _this.hyoukaStampHeibonText.show();

              Util_1.Util.playAudio(_this.scene, 'jingle_heibon');
            }
          }, 4000);
        };

        ResultSubScene.prototype.onUpdate = function () {//
        };

        ResultSubScene.prototype.stopContent = function () {//
        };

        ResultSubScene.prototype.hideContent = function () {
          this.background.hide();
          this.titleBackground.hide();
          this.titleLabel.hide();
          this.hyoukaText.hide();
          this.hyoukaStampHighLevelText.hide();
          this.hyoukaStampHeibonText.hide();
          this.hyoukaStampDemoText.hide();
          this.hyoukaPerfectText.hide();
        };

        ResultSubScene.prototype.calculateHyouka = function (states) {
          var _this = this;

          var pointsPerfect = states.reduce(function (prev, current) {
            return prev + _this.state2point(1
            /* Great */
            );
          }, 0);
          var points = states.reduce(function (prev, current) {
            return prev + _this.state2point(current);
          }, 0);
          var failedCount = states.filter(function (v) {
            return v === 3
            /* Fail */
            ;
          }).length;
          console.log("result: " + points + "/" + pointsPerfect + " (" + failedCount + " miss)");

          var hyoukaStamp = function () {
            if (points === pointsPerfect) {
              return HyoukaStamp.Perfect;
            }

            if (points > pointsPerfect - 6 && failedCount < 2) {
              return HyoukaStamp.HighLevel;
            }

            if (points > pointsPerfect - 12) {
              return HyoukaStamp.DemoHeibon;
            }

            return HyoukaStamp.Heibon;
          }();

          var hyoukaMessage = function () {
            if (hyoukaStamp === HyoukaStamp.Perfect) {
              return '完璧に歩けてた';
            }

            if (hyoukaStamp === HyoukaStamp.HighLevel) {
              return 'ちゃんと歩けてた';
            }

            if (hyoukaStamp === HyoukaStamp.DemoHeibon) {
              var q1Index_1 = Math.ceil((states.length - 1) / 4);
              var q2Index_1 = Math.ceil((states.length - 1) / 2);
              var q3Index_1 = Math.ceil((states.length - 1) / 4 * 3);
              var blockNum_1 = q1Index_1;
              var quarterScore = states.reduce(function (prev, current, index) {
                var point = _this.state2point(current); // console.log('index: ', index, point);


                if (index < blockNum_1) {
                  // console.log('increment 0');
                  prev[0] += point;
                }

                if (q1Index_1 <= index && index < q1Index_1 + blockNum_1) {
                  // console.log('increment 1');
                  prev[1] += point;
                }

                if (q2Index_1 <= index && index < q2Index_1 + blockNum_1) {
                  // console.log('increment 2');
                  prev[2] += point;
                }

                if (q3Index_1 <= index && index < q3Index_1 + blockNum_1) {
                  // console.log('increment 3');
                  prev[3] += point;
                }

                return prev;
              }, [0, 0, 0, 0]); // console.log(quarterScore);

              var bestQuarter = quarterScore.indexOf(Math.max.apply(Math, quarterScore));

              switch (bestQuarter) {
                case 0:
                  return '最初よくできてた';

                case 1:
                case 2:
                  return '中盤よくできてた';

                default:
                  // case 4
                  return '最後よくできてた';
              }
            } // Heibon


            return 'もう少しがんばろう';
          }();

          console.log(hyoukaStamp, hyoukaMessage);
          return {
            points: points,
            stamp: hyoukaStamp,
            message: hyoukaMessage
          };
        };

        ResultSubScene.prototype.state2point = function (state) {
          switch (state) {
            case 0
            /* Waiting */
            :
            case 1
            /* Great */
            :
              return 2;

            case 2
            /* Good */
            :
              return 1;

            case 3
            /* Fail */
            :
              return -2;
          }
        };

        return ResultSubScene;
      }(SubScene_1.SubScene);

      exports.ResultSubScene = ResultSubScene;
    }, {
      "../component/Label": 10,
      "../component/Messenger": 11,
      "../component/RoundedFilledRect": 14,
      "../util/Util": 29,
      "./SubScene": 23
    }],
    23: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * 具体的なシーンの処理と表示を行う抽象クラス
       */

      var SubScene =
      /** @class */
      function (_super) {
        __extends(SubScene, _super);

        function SubScene(_scene) {
          return _super.call(this, {
            scene: _scene,
            width: _scene.game.width,
            height: _scene.game.height
          }) || this;
        }

        return SubScene;
      }(g.E);

      exports.SubScene = SubScene;
    }, {}],
    24: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var SubScene_1 = require("./SubScene");

      var Util_1 = require("../util/Util");

      var Label_1 = require("../component/Label");

      var TitleSubScene =
      /** @class */
      function (_super) {
        __extends(TitleSubScene, _super);

        function TitleSubScene(_scene) {
          var _this = _super.call(this, _scene) || this;

          _this.onTitleSceneEnd = new g.Trigger();
          return _this;
        }

        TitleSubScene.prototype.init = function () {
          this.titleLabel = new Label_1.BoldBlack128pxLabel({
            scene: this.scene,
            text: '鳥の行進',
            fontSize: 60
          });
          this.titleLabel.x = (this.scene.game.width - this.titleLabel.width) / 2;
          this.titleLabel.y = (this.scene.game.height - this.titleLabel.height) / 2;
          this.append(this.titleLabel);
          this.hideContent();
        };

        TitleSubScene.prototype.showContent = function () {
          this.titleLabel.show();
        };

        TitleSubScene.prototype.startContent = function () {
          var _this = this;

          this.scene.setTimeout(function () {
            Util_1.Util.playAudio(_this.scene, 'opening');
            _this.titleEndTimer = _this.scene.setTimeout(function () {
              _this.titleEndTimer = null;

              _this.onTitleSceneEnd.fire();
            }, 6500);
          }, 1000);
        };

        TitleSubScene.prototype.onUpdate = function () {//
        };

        TitleSubScene.prototype.stopContent = function () {
          if (this.titleEndTimer && !this.titleEndTimer.destroyed()) {
            this.titleEndTimer.destroy();
            this.titleEndTimer = null;
          }
        };

        TitleSubScene.prototype.hideContent = function () {
          this.titleLabel.hide();
        };

        return TitleSubScene;
      }(SubScene_1.SubScene);

      exports.TitleSubScene = TitleSubScene;
    }, {
      "../component/Label": 10,
      "../util/Util": 29,
      "./SubScene": 23
    }],
    25: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var SubScene_1 = require("./SubScene");

      var Util_1 = require("../util/Util");

      var TeachingTap_1 = require("../component/TeachingTap");

      var TeachingSlide_1 = require("../component/TeachingSlide");

      var RoundedFilledRect_1 = require("../component/RoundedFilledRect");

      var JoinButton_1 = require("../component/JoinButton");

      var StopJoinButton_1 = require("../component/StopJoinButton");

      var Messenger_1 = require("../component/Messenger");

      var Label_1 = require("../component/Label");

      var StartButton_1 = require("../component/StartButton");

      var GameManager_1 = require("../component/GameManager");

      var TutorialScore_1 = require("../score/TutorialScore");

      var WaitingRoomSubScene =
      /** @class */
      function (_super) {
        __extends(WaitingRoomSubScene, _super);

        function WaitingRoomSubScene(_scene, playerJoiningManager) {
          var _this = _super.call(this, _scene) || this;

          _this.playerJoiningManager = playerJoiningManager;
          _this.onSceneEnd = new g.Trigger();
          _this.messenger = new Messenger_1.Messenger(_scene);
          return _this;
        }

        WaitingRoomSubScene.prototype.init = function () {
          var _this = this;

          this.manager = new GameManager_1.GameManager({
            scene: this.scene,
            score: TutorialScore_1.default,
            loop: true
          });
          this.titleLabel = new Label_1.MediumBlack64pxLabel({
            scene: this.scene,
            text: '鳥の行進',
            fontSize: 30
          });
          this.titleLabel.x = 5;
          this.titleLabel.y = 5;
          this.append(this.titleLabel);
          this.playerNumLabel = new Label_1.MediumBlack64pxLabel({
            scene: this.scene,
            text: '参加人数      人',
            fontSize: 30
          });
          this.playerNumLabel.x = g.game.width - this.playerNumLabel.width - 5;
          this.playerNumLabel.y = 5;
          this.append(this.playerNumLabel);
          this.playerNumValueLabel = new Label_1.MediumBlack64pxLabel({
            scene: this.scene,
            text: '0',
            fontSize: 30
          });
          this.playerNumValueLabel.x = g.game.width - 75 - this.playerNumValueLabel.width / 2;
          this.playerNumValueLabel.y = this.playerNumLabel.y;
          this.append(this.playerNumValueLabel);
          this.teachingBackground = new RoundedFilledRect_1.RoundedFilledRect({
            scene: this.scene,
            width: 360,
            height: 300,
            x: 20,
            y: 50,
            borderRadius: 20,
            cssColor: '#f0fbff',
            circleAssetId: 'lightblue_circle_32',
            circleAssetSize: 32
          });
          this.append(this.teachingBackground);
          this.teachingTap = new TeachingTap_1.TeachingTap({
            scene: this.scene
          });
          this.teachingSlide = new TeachingSlide_1.TeachingSlide({
            scene: this.scene
          });
          this.teachingTap.x = 50;
          this.teachingTap.y = 50;
          this.teachingSlide.x = 220;
          this.teachingSlide.y = 50;
          this.append(this.teachingTap);
          this.append(this.teachingSlide);
          this.stopJoinButton = new StopJoinButton_1.StopJoinButton({
            scene: this.scene
          });
          this.stopJoinButton.x = this.scene.game.width - this.stopJoinButton.width - 20;
          this.stopJoinButton.y = this.scene.game.height - this.stopJoinButton.height - 20;
          this.stopJoinButton.pointUp.add(function () {
            // only game master fire
            console.log('stop join', _this.playerJoiningManager.players);

            _this.messenger.send('gameStart', null);
          });
          this.append(this.stopJoinButton);
          this.joinButton = new JoinButton_1.JoinButton({
            scene: this.scene
          });
          this.joinButton.x = this.scene.game.width - this.joinButton.width - 20;
          this.joinButton.y = this.scene.game.height - this.joinButton.height - 20;
          this.joinButton.pointUp.add(function () {
            if (_this.playerJoiningManager.isJoined()) {
              return;
            }

            _this.playerJoiningManager.join();

            _this.joinButton.setJoined();
          });
          this.append(this.joinButton);
          this.atsumaruStartButton = new StartButton_1.StartButton({
            scene: this.scene
          });
          this.atsumaruStartButton.x = this.scene.game.width - this.atsumaruStartButton.width - 20;
          this.atsumaruStartButton.y = this.scene.game.height - this.atsumaruStartButton.height - 20;
          this.atsumaruStartButton.pointUp.add(function () {
            _this.onSceneEnd.fire();
          });
          this.append(this.atsumaruStartButton);
          this.hideContent();
          this.messenger.onReceive('gameStart', function () {
            _this.onSceneEnd.fire();
          });
          var pipyakoCount = 0;
          this.manager.onBeat.add(function (event) {
            if (pipyakoCount > 0) {
              pipyakoCount++;
            }

            if (event.action === 3
            /* PiPyako */
            ) {
                pipyakoCount = 1; // tap

                _this.teachingTap.opacity = 1;
                _this.teachingSlide.opacity = 0.3;

                _this.teachingTap.modified();

                _this.teachingSlide.modified();

                _this.teachingTap.action(event.beatIndex);

                return;
              }

            if (pipyakoCount === 3) {
              // しゃがみ
              _this.teachingTap.opacity = 0.3;
              _this.teachingSlide.opacity = 1;

              _this.teachingTap.modified();

              _this.teachingSlide.modified();

              _this.teachingSlide.slideDown();

              return;
            }

            if (pipyakoCount === 4) {
              pipyakoCount = 0; // ジャンプ

              _this.teachingSlide.slideUp();

              return;
            }

            if (event.action === 2
            /* Normal */
            ) {
                // tap
                _this.teachingTap.opacity = 1;
                _this.teachingSlide.opacity = 0.3;

                _this.teachingTap.modified();

                _this.teachingSlide.modified();

                _this.teachingTap.action(event.beatIndex);
              } // not reached

          });
        };

        WaitingRoomSubScene.prototype.showContent = function () {
          this.titleLabel.show();

          if (!Util_1.Util.isAtsumaruEnv()) {
            this.playerNumLabel.show();
            this.playerNumValueLabel.show();
          }

          this.teachingTap.show();
          this.teachingSlide.show();
          this.teachingBackground.show();

          if (Util_1.Util.isAtsumaruEnv()) {
            this.atsumaruStartButton.show();
          } else {
            if (this.playerJoiningManager.isGameMaster()) {
              this.stopJoinButton.show();
            } else {
              this.joinButton.show();
            }
          }
        };

        WaitingRoomSubScene.prototype.startContent = function () {
          var _this = this;

          this.playerNumValueLabel.text = "" + this.playerJoiningManager.players.length;
          this.playerNumValueLabel.invalidate();
          this.playerJoiningManager.onPlayerJoin.add(function (event) {
            console.log('onPlayerJoin', event.player, _this.playerJoiningManager.players);
            _this.playerNumValueLabel.text = "" + _this.playerJoiningManager.players.length;

            _this.playerNumValueLabel.invalidate();
          });
          this.manager.start(); // this.timeline = new Timeline(this.scene);
          // this.timeline.create(this.scene)
          //   .wait(1000)
          //   .call(() => {
          //     this.teachingTap.show();
          //     this.teachingTap.startAnimation();
          //     Util.playAudio(this.scene, 'peta1');
          //     this.manager.start();
          //   })
          //   .wait(3000)
          //   .call(() => {
          //     this.teachingSlide.show();
          //     this.teachingSlide.startAnimation();
          //     Util.playAudio(this.scene, 'peta1');
          //   })
          //   .wait(5000);
        };

        WaitingRoomSubScene.prototype.onUpdate = function () {//
        };

        WaitingRoomSubScene.prototype.stopContent = function () {
          if (this.titleEndTimer && !this.titleEndTimer.destroyed()) {
            this.titleEndTimer.destroy();
            this.titleEndTimer = null;
          }

          this.manager.stop(); // this.timeline.clear();
        };

        WaitingRoomSubScene.prototype.hideContent = function () {
          this.titleLabel.hide();
          this.playerNumLabel.hide();
          this.playerNumValueLabel.hide();
          this.teachingTap.hide();
          this.teachingSlide.hide();
          this.teachingBackground.hide();
          this.joinButton.hide();
          this.stopJoinButton.hide();
          this.atsumaruStartButton.hide();
        };

        return WaitingRoomSubScene;
      }(SubScene_1.SubScene);

      exports.WaitingRoomSubScene = WaitingRoomSubScene;
    }, {
      "../component/GameManager": 7,
      "../component/JoinButton": 9,
      "../component/Label": 10,
      "../component/Messenger": 11,
      "../component/RoundedFilledRect": 14,
      "../component/StartButton": 15,
      "../component/StopJoinButton": 16,
      "../component/TeachingSlide": 17,
      "../component/TeachingTap": 18,
      "../score/TutorialScore": 27,
      "../util/Util": 29,
      "./SubScene": 23
    }],
    26: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.default = {
        bpm: 120,
        beat: 4,
        fragments: [{
          assetId: 'music1',
          beatAction: [0
          /* Count */
          , null, 0
          /* Count */
          , null]
        }, {
          assetId: 'music2',
          beatAction: [0
          /* Count */
          , 0
          /* Count */
          , 0
          /* Count */
          , 1
          /* LastCount */
          ]
        }, {
          assetId: 'music3',
          beatAction: [2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music4',
          beatAction: [3
          /* PiPyako */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music5',
          beatAction: [2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music6',
          beatAction: [3
          /* PiPyako */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music7',
          beatAction: [2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music8',
          beatAction: [3
          /* PiPyako */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music9',
          beatAction: [2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music10',
          beatAction: [3
          /* PiPyako */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music11',
          beatAction: [2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music12',
          beatAction: [3
          /* PiPyako */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music13',
          beatAction: [2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music14',
          beatAction: [3
          /* PiPyako */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music15',
          beatAction: [2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music16',
          beatAction: [2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music17',
          beatAction: [2
          /* Normal */
          , 2
          /* Normal */
          , 3
          /* PiPyako */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music18',
          beatAction: [3
          /* PiPyako */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music19',
          beatAction: [2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music20',
          beatAction: [2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music21',
          beatAction: [2
          /* Normal */
          , 2
          /* Normal */
          , 3
          /* PiPyako */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music22',
          beatAction: [3
          /* PiPyako */
          , 2
          /* Normal */
          , 3
          /* PiPyako */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music23',
          beatAction: [2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music24',
          beatAction: [2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music25',
          beatAction: [2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music26',
          beatAction: [3
          /* PiPyako */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music27',
          beatAction: [2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music28',
          beatAction: [3
          /* PiPyako */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music29',
          beatAction: [2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music30',
          beatAction: [3
          /* PiPyako */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music31',
          beatAction: [2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music32',
          beatAction: [3
          /* PiPyako */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music33',
          beatAction: [2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music34',
          beatAction: [3
          /* PiPyako */
          , 2
          /* Normal */
          , 3
          /* PiPyako */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music35',
          beatAction: [2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music36',
          beatAction: [2
          /* Normal */
          , 3
          /* PiPyako */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music37',
          beatAction: [3
          /* PiPyako */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music38',
          beatAction: [2
          /* Normal */
          , 3
          /* PiPyako */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music39',
          beatAction: [2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music40',
          beatAction: [2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music41',
          beatAction: [3
          /* PiPyako */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music42',
          beatAction: [3
          /* PiPyako */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music43',
          beatAction: [3
          /* PiPyako */
          , 2
          /* Normal */
          , 3
          /* PiPyako */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music44',
          beatAction: [2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music45',
          beatAction: [2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music46',
          beatAction: [2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music47',
          beatAction: [2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music48',
          beatAction: [2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'music49',
          beatAction: [2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }]
      };
    }, {}],
    27: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.default = {
        bpm: 120,
        beat: 4,
        fragments: [{
          assetId: 'tutorial1',
          beatAction: [2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'tutorial3',
          beatAction: [2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'tutorial2',
          beatAction: [2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }, {
          assetId: 'tutorial2',
          beatAction: [3
          /* PiPyako */
          , 2
          /* Normal */
          , 2
          /* Normal */
          , 2
          /* Normal */
          ]
        }]
      };
    }, {}],
    28: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * 起動方法
       * @export
       * @enum {number}
       */

      var LaunchType;

      (function (LaunchType) {
        /** 未指定 */
        LaunchType[LaunchType["NOTHING"] = 0] = "NOTHING";
        /** 放送者プレイ */

        LaunchType[LaunchType["SELF"] = 1] = "SELF";
        /** 抽選されたユーザーがプレイ */

        LaunchType[LaunchType["LOTTERY"] = 2] = "LOTTERY";
        /** みんなでプレイ */

        LaunchType[LaunchType["RANKING"] = 3] = "RANKING";
      })(LaunchType = exports.LaunchType || (exports.LaunchType = {}));
      /** 起動方法の放送者プレイを判定する文字列 */


      var LAUNCH_TYPE_SELF_STRING = 'self';
      /** 起動方法の抽選されたユーザーがプレイを判定する文字列 */

      var LAUNCH_TYPE_LOTTERY_STRING = 'lottery';
      /** 起動方法のみんなでプレイを判定する文字列 */

      var LAUNCH_TYPE_RANKING_STRING = 'ranking';

      var GameParameters =
      /** @class */
      function () {
        function GameParameters() {}
        /**
         * 起動パラメータから対応するメンバ変数を設定する
         * @param {SessionParameters} parameters 起動パラメータ
         */


        GameParameters.init = function (parameters) {
          this.launchType = LaunchType.NOTHING;

          if (typeof parameters.launchType === 'string') {
            if (parameters.launchType === LAUNCH_TYPE_SELF_STRING) {
              this.launchType = LaunchType.SELF;
            } else if (parameters.launchType === LAUNCH_TYPE_LOTTERY_STRING) {
              this.launchType = LaunchType.LOTTERY;
            } else if (parameters.launchType === LAUNCH_TYPE_RANKING_STRING) {
              this.launchType = LaunchType.RANKING;
            }
          }

          if (parameters.totalTimeLimit) {
            this.totalTimeLimit = parameters.totalTimeLimit;
          }
        };

        return GameParameters;
      }();

      exports.GameParameters = GameParameters;
    }, {}],
    29: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var Util =
      /** @class */
      function () {
        function Util() {}

        Util.playAudio = function (scene, assetId) {
          scene.assets[assetId].play();
        };

        Util.stopAudio = function (scene, assetId) {
          scene.assets[assetId].stop();
        };

        Util.isAtsumaruEnv = function () {
          return true; // return typeof window !== 'undefined' && typeof (window as any).RPGAtsumaru !== 'undefined';
        };

        return Util;
      }();

      exports.Util = Util;
    }, {}]
  }, {}, [19])(19);
});